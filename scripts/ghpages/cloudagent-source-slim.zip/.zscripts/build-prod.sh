#!/bin/bash
# ============================================================================
# v101 build-prod.sh — rebuild the production bundle and restart prod safely.
#
# WHY: the sandbox is a hard 4GB cgroup with no swap and no root. A Turbopack
# `next build` OOM-kills twice out of two attempts even with the dev server
# dead (3.5GB free) — its Rust workers ignore NODE_OPTIONS heap caps. The
# WEBPACK build (`next build --webpack`) keeps its memory inside the JS heap,
# respects the cap, and succeeds reliably. Rebuilds MUST use this script.
#
# Safe sequence (the :3000 probes of the watchdog/supervisor must never fail
# long enough to trigger a dev-mode recovery that would wipe .next):
#   1. kill prod server → placeholder HTTP server on :3000 within ~1s
#   2. webpack build (2-4 min)
#   3. swap placeholder → next start within ~1s
#   4. verify probe
#
# Rollback to dev mode any time:  rm .prodmode  &&  bash .zscripts/dev.sh-restart
# (or simply remove .prodmode — the next recovery falls back to next dev).
# ============================================================================
set -u
BASE=/home/z/my-project
LOG="$BASE/dev-watchdog.log"
HEAP_CAP=1400
log() { echo "[build-prod $(date '+%H:%M:%S')] $*"; }

cd "$BASE" || exit 1
[ -f "$BASE/.prodmode" ] || { echo "refusing: .prodmode marker absent (platform is in dev mode)"; exit 1; }

# 1) stop prod server, hold :3000 with a placeholder
kill_platform_next() {
  for pid in $(ls /proc 2>/dev/null | grep -E '^[0-9]+$'); do
    cwd=$(readlink "/proc/$pid/cwd" 2>/dev/null) || continue
    [ "$cwd" = "$BASE" ] || continue
    cmd=$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null)
    # v125: also kill any DEV server — `next dev` on :3000 used to survive the
    # prod swap and keep serving (or fight the port) after a recycle.
    case "$cmd" in *"next start"*|*next-server*|*"next dev"*) kill -9 "$pid" 2>/dev/null;; esac
  done
}
kill_platform_next
nohup python3 -m http.server 3000 --bind 127.0.0.1 >/dev/null 2>&1 &
PH=$!
sleep 1
curl -s -o /dev/null --max-time 3 http://localhost:3000/ || { log "placeholder failed to bind"; exit 1; }
log "placeholder up — building (webpack, heap ${HEAP_CAP}MB)"

# 2) build — WEBPACK (Turbopack OOMs this box; see header)
rm -rf .next-prod-backup.new
cp -al .next .next-prod-backup.new 2>/dev/null || true
if ! NODE_OPTIONS="--max-old-space-size=${HEAP_CAP}" \
     PATH="$BASE/node_modules/.bin:$PATH" \
     next build --webpack > "$BASE/.build-prod.log" 2>&1; then
  log "BUILD FAILED — restoring previous build"
  tail -15 "$BASE/.build-prod.log"
  rm -rf .next.failed && mv .next .next.failed 2>/dev/null
  [ -d .next-prod-backup.new ] && { cp -al .next-prod-backup.new/. .next 2>/dev/null; }
  kill $PH 2>/dev/null
  NODE_OPTIONS="--max-old-space-size=1280" PATH="$BASE/node_modules/.bin:$PATH" \
    setsid nohup bash -c "cd '$BASE' && exec next start -p 3000 >> dev.log 2>&1" </dev/null >/dev/null 2>&1 &
  exit 1
fi
rm -rf .next-prod-backup
mv .next-prod-backup.new .next-prod-backup 2>/dev/null
log "build OK ($(cat .next/BUILD_ID 2>/dev/null)) — swapping to new server"

# 3) swap placeholder → prod (sub-second gap)
NODE_OPTIONS="--max-old-space-size=1280" PATH="$BASE/node_modules/.bin:$PATH" \
  setsid nohup bash -c "kill $PH 2>/dev/null; cd '$BASE' && exec next start -p 3000 >> dev.log 2>&1" </dev/null >/dev/null 2>&1 &

# 4) verify
for i in $(seq 1 20); do
  sleep 2
  if curl -s -o /dev/null --max-time 3 http://localhost:3000/api/lock; then
    log "prod server UP (attempt $i)"
    exit 0
  fi
done
log "prod server did NOT come up — check dev.log"
exit 1
