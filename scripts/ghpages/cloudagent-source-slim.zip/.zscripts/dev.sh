#!/bin/bash
# ============================================================================
# v79 boot flow — /start.sh prefers THIS over the default bun+mini-services
# flow when this file exists. Everything here runs as a child of the sandbox
# init (tini), which makes the whole tree survive tool-session cleanups.
#
# Why this exists: next dev (default flow, no memory cap) ballooned to 2.1GB
# RSS on the 4GB-no-swap sandbox and was OOM-killed → 502 everywhere, orphaned
# project runs holding ports/RAM, and manual restarts got reaped between
# tool calls. This script is the supervisor of record for every future boot:
#   - next dev with a hard JS-heap cap (1280MB)
#   - cold .next clear on every (re)start (chunk consistency)
#   - orphaned project-run reaping before each restart
#   - automatic respawn when :3000 or :3001 die
# ============================================================================
set -u
BASE=/home/z/my-project
HEAP_CAP=1280
WLOG="$BASE/dev-watchdog.log"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] [boot] $*" >> "$WLOG"; }

cd "$BASE" || exit 1

# ---- v125 RECYCLE-GUARD DB SNAPSHOT (keep last 7) ----
# The sandbox container recycle has WIPED db/custom.db repeatedly (5th wipe
# happened 2026-10-20 — the owner's project died in it). Snapshot the DB at
# every boot so a wiped DB can be restored from the newest backup.
mkdir -p "$BASE/db/backups"
cp "$BASE/db/custom.db" "$BASE/db/backups/custom-$(date +%Y%m%d-%H%M%S).db" 2>/dev/null
ls -1t "$BASE/db/backups"/custom-*.db 2>/dev/null | tail -n +8 | xargs -r rm -f


# v127 — RESTORE-FROM-GIT: gitignored db/*.db gets WIPED on every sandbox
# recycle (7th wipe confirmed 2026-10-20 21:46). db/state/ is force-tracked in
# git, so a checkpoint committed after setup SURVIVES recycles. If the live DB
# is gone but a checkpoint exists, restore it BEFORE db:push/boot-heal — the
# owner's Razorpay keys, GitHub connections and users come back intact.
if [ ! -f "$BASE/db/custom.db" ] && [ -f "$BASE/db/state/custom-latest.db" ]; then
  log "v127 DB RESTORE: live DB missing — restoring from git-tracked checkpoint"
  cp "$BASE/db/state/custom-latest.db" "$BASE/db/custom.db"
fi

# ---- deps + database (idempotent: no-ops when already present) ----
[ -d node_modules ] || bun install
bun run db:push || true

# ---- kill orphaned project-run processes (cwd inside projects/) ----
kill_orphans() {
  local n=0
  for pid in $(ls /proc 2>/dev/null | grep -E '^[0-9]+$'); do
    cwd=$(readlink "/proc/$pid/cwd" 2>/dev/null) || continue
    case "$cwd" in
      "$BASE/projects/"*) kill -9 "$pid" 2>/dev/null && n=$((n+1)) ;;
    esac
  done
  [ "$n" -gt 0 ] && log "killed $n orphan(s)"
}

# ---- probe helper ----
probe() { curl -s -o /dev/null --max-time 20 "http://localhost:$1/api/lock" 2>/dev/null; }
probe_socket() { curl -s -o /dev/null --max-time 8 "http://localhost:3001/" 2>/dev/null; }

# v86 FIX (owner: "Run problem"): `pkill -f "next dev"` also killed GENERATED
# apps running `next dev -p 4xxx` (their cwd is projects/<id>). Recovery may
# only kill the PLATFORM's own next processes — cwd == $BASE exactly.
kill_platform_next() {
  local n=0
  for pid in $(ls /proc 2>/dev/null | grep -E '^[0-9]+$'); do
    cwd=$(readlink "/proc/$pid/cwd" 2>/dev/null) || continue
    [ "$cwd" = "$BASE" ] || continue
    cmd=$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null)
    case "$cmd" in
      *"next dev"*|*next-server*) kill -9 "$pid" 2>/dev/null && n=$((n+1)) ;;
    esac
  done
  [ "$n" -gt 0 ] && log "killed $n platform next process(es)"
}

# ---- cold start both services ----
# v101 SPEED MODE: when the marker file .prodmode exists AND a production
# build is present (.next/BUILD_ID), the platform web runs `next start` —
# ~4x less RAM than next dev (frees ~1.3GB for parallel AI builds on the
# 4GB box) and zero compile-on-first-hit latency. Any other case falls
# back to the proven next dev path (cold .next clear keeps chunk consistency).
start_web() {
  kill_orphans
  kill_platform_next
  if [ -f "$BASE/.prodmode" ] && [ -f "$BASE/.next/BUILD_ID" ]; then
    log "starting next START (production build — prodmode marker present)"
    NODE_OPTIONS="--max-old-space-size=${HEAP_CAP}" \
      PATH="$BASE/node_modules/.bin:$PATH" \
      bash -c "cd '$BASE' && exec next start -p 3000 2>&1 | tee -a '$BASE/dev.log'" &
  else
    # v125 GUARD: the cold .next clear exists for dev chunk consistency — but
    # it used to WIPE A VALID PRODUCTION BUILD whenever dev.sh fell back to
    # the dev branch (that's how the owner's live prod build vanished after a
    # recycle). With .prodmode present, never destroy .next here.
    if [ -f "$BASE/.prodmode" ]; then
      log "dev fallback with .prodmode — PRESERVING .next (no cold clear)"
    else
      rm -rf "$BASE/.next"
    fi
    log "starting next dev (heap cap ${HEAP_CAP}MB)"
    NODE_OPTIONS="--max-old-space-size=${HEAP_CAP}" \
      PATH="$BASE/node_modules/.bin:$PATH" \
      bash -c "cd '$BASE' && exec next dev -p 3000 2>&1 | tee -a '$BASE/dev.log'" &
  fi
}
start_socket() {
  pkill -f "bun --hot index.ts" 2>/dev/null
  # v87: agent-service deps can vanish (snapshot restores, cleanups) — the old
  # code just spawned bun and crash-looped SILENTLY for ever (no logs anywhere,
  # watchdog restarted every 50s, realtime features dead). Install idempotently
  # and always capture the output.
  if [ ! -d "$BASE/mini-services/agent-service/node_modules/socket.io" ]; then
    log "agent-service deps missing — installing"
    (cd "$BASE/mini-services/agent-service" && bun install >> "$BASE/socket-service.log" 2>&1)
  fi
  log "starting socket service (:3001)"
  bash -c "cd '$BASE/mini-services/agent-service' && exec bun --hot index.ts >> '$BASE/socket-service.log' 2>&1" &
}

# v102.2 ZOMBIE SWEEP: the sandbox container recycle re-imports untracked
# base-image files. The Drive system was removed in v91/v100 — when a recycle
# resurrects these zombies, this boot-time sweep deletes them again so
# /api/gdrive can never serve and v91's suite can never regress.
for z in src/app/api/gdrive src/app/api/sdks/drive src/lib/gdrive.ts scripts/e2e-v80-publish-gdrive.js; do
  [ -e "$BASE/$z" ] && { rm -rf "$BASE/$z"; log "zombie sweep: removed $z (recycle resurrected it)"; }
done

log "=== boot flow start (pid $$) ==="
start_web
start_socket

# give both a boot window before supervising
sleep 60

# ---- supervision loop (this script never exits — init keeps it alive) ----
while true; do
  if ! probe 3000; then
    log "web :3000 DOWN — restarting"
    start_web
    sleep 60
  fi
  if ! probe_socket; then
    log "socket :3001 DOWN — restarting"
    start_socket
    sleep 30
  fi
  sleep 20
done
