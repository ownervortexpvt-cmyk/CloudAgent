import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // v113 — standalone output copies ALL of node_modules into .next/standalone
  // (~1.4GB extra per build). On toolchain-heavy boxes (Flutter + Android SDK
  // + local GGUF models resident) that ENOSPC-kills every rebuild. standalone
  // is ONLY needed for the FC deploy artifact (.zscripts/build.sh), which sets
  // DEPLOY_BUILD=1. Local prod rebuilds (.zscripts/build-prod.sh → next start)
  // build light and run the same server from the repo's node_modules.
  ...(process.env.DEPLOY_BUILD === "1" ? { output: "standalone" as const } : {}),
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // v116 — ULTRA SPEED: lucide-react's barrel is ~1500 icon modules; per-icon
  // imports cut hundreds of KB of dead icon code out of every client chunk.
  // gzip on (default) + no powered-by header (fingerprint surface removed).
  poweredByHeader: false,
  experimental: {
    optimizePackageImports: ['lucide-react', 'date-fns'],
    // v97 — Next 16 truncates request bodies at 10MB when middleware (proxy)
    // matches the route, which silently killed 1GB zip imports. The route
    // enforces its own 1GB+16MB cap; this only lifts the framework wall.
    proxyClientMaxBodySize: 1258291200, // 1.2GB in bytes
  },
};

export default nextConfig;
