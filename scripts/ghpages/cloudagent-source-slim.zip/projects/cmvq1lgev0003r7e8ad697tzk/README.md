# Hello World Full Stack Application

## Overview
A complete full-stack application with Flutter frontend, Node.js/Express backend, and admin dashboard.

## Project Structure
```
├── lib/                    # Flutter app (frontend)
├── admin/                  # Admin dashboard
│   ├── index.html         # Admin dashboard HTML
│   ├── app.js             # Admin app JavaScript
│   └── style.css          # Admin app CSS
├── data/                  # Database storage
│   └── hello_checks.json  # Health check data
├── server.js              # Express backend server
├── package.json           # Backend dependencies
└── hello.txt              # Original file (HEALTHCHECK-OK)
```

## Features

### Backend Server (server.js)
- REST API endpoints for health checks
- JSON file-based persistence
- Static file serving for both apps
- CORS enabled for cross-origin requests

### Database (data/hello_checks.json)
- JSON file storage for health check data
- Survives server restarts
- Tracks: health checks, statistics, server status

### Admin Dashboard (admin/)
- Role-based access control (admin/admin123)
- Real-time dashboard with statistics
- CRUD operations for health checks
- Responsive design

### Flutter Frontend (lib/)
- Original Flutter app (keep and reuse)
- Will connect to backend API

## API Endpoints

### Health Check API
- `GET /api/health` - Health check endpoint
- `GET /api/healthchecks` - Get all health checks
- `POST /api/healthchecks` - Create new health check
- `GET /api/stats` - Get application statistics

## Installation & Running

### Backend Server
```bash
npm install
npm start
```

### Admin Dashboard
- Access at: http://localhost:3001/admin
- Login: admin / admin123

## Development

### Backend Development
```bash
npm run dev  # with nodemon
```

### Database
- Uses JSON file storage in `/data/`
- Automatic initialization on server start
- Data persists between restarts

## Security Note
- This demo uses simple authentication
- In production, implement proper authentication (JWT, OAuth, etc.)
- Use environment variables for sensitive data

## Deployment
- Backend server runs on port 3001
- Both frontend apps served statically from the same server
- Database stored as JSON file (can be replaced with SQLite/PostgreSQL)