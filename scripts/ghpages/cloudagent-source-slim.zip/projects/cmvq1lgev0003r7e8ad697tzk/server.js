const express = require('express');
const cors = require('cors');
const fs = require('fs').promises;
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'hello_checks.json');

// Initialize data directory and database
async function initDatabase() {
    try {
        await fs.access(DATA_DIR);
    } catch {
        await fs.mkdir(DATA_DIR, { recursive: true });
    }
    
    try {
        await fs.access(DB_FILE);
    } catch {
        await fs.writeFile(DB_FILE, JSON.stringify({
            healthchecks: [],
            stats: {
                total_checks: 0,
                last_check: null,
                server_status: 'running'
            }
        }, null, 2));
    }
}

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', message: 'Health check passed' });
});

// Get health checks
app.get('/api/healthchecks', async (req, res) => {
    try {
        const data = await fs.readFile(DB_FILE, 'utf8');
        const db = JSON.parse(data);
        res.json(db.healthchecks);
    } catch (error) {
        res.status(500).json({ error: 'Failed to read health checks' });
    }
});

// Add health check
app.post('/api/healthchecks', async (req, res) => {
    try {
        const { message = 'HEALTHCHECK-OK', timestamp = new Date().toISOString() } = req.body;
        const checkId = uuidv4();
        
        const data = await fs.readFile(DB_FILE, 'utf8');
        const db = JSON.parse(data);
        
        const newCheck = {
            id: checkId,
            message,
            timestamp,
            status: 'OK'
        };
        
        db.healthchecks.unshift(newCheck);
        db.stats.total_checks++;
        db.stats.last_check = timestamp;
        
        await fs.writeFile(DB_FILE, JSON.stringify(db, null, 2));
        
        res.status(201).json(newCheck);
    } catch (error) {
        res.status(500).json({ error: 'Failed to create health check' });
    }
});

// Get stats
app.get('/api/stats', async (req, res) => {
    try {
        const data = await fs.readFile(DB_FILE, 'utf8');
        const db = JSON.parse(data);
        res.json(db.stats);
    } catch (error) {
        res.status(500).json({ error: 'Failed to read stats' });
    }
});

// Serve admin app
app.use(express.static(path.join(__dirname, 'admin')));

// Serve Flutter app
app.use(express.static(path.join(__dirname, 'lib')));

// Serve root
app.get('/', (req, res) => {
    res.send('<h1>Hello World Backend Server</h1><p><a href="/admin">Admin Dashboard</a></p>');
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    initDatabase();
});