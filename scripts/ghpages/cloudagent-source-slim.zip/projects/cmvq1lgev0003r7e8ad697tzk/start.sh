#!/bin/bash

# Start the backend server
echo "Starting Hello World Backend Server..."
npm start &

# Wait for server to start
sleep 3

echo "Server is running on http://localhost:3001"
echo "Admin Dashboard: http://localhost:3001/admin"
echo "Login: admin / admin123"
echo ""
echo "Press Ctrl+C to stop the server"