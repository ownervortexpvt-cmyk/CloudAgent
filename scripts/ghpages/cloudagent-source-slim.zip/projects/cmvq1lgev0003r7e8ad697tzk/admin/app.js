// Admin app JavaScript
class AdminApp {
    constructor() {
        this.apiBase = '/api';
        this.init();
    }

    init() {
        this.checkAuth();
        this.setupEventListeners();
    }

    checkAuth() {
        const token = localStorage.getItem('adminToken');
        if (token) {
            this.showDashboard();
        } else {
            this.showLoginForm();
        }
    }

    setupEventListeners() {
        const loginForm = document.getElementById('loginFormElement');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }
    }

    async handleLogin(e) {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        // Simple authentication (in production, use proper auth)
        if (username === 'admin' && password === 'admin123') {
            localStorage.setItem('adminToken', 'mock-token');
            this.showDashboard();
        } else {
            alert('Invalid credentials');
        }
    }

    showDashboard() {
        document.getElementById('loginForm').style.display = 'none';
        document.getElementById('dashboard').classList.add('active');
        this.loadStats();
        this.loadHealthChecks();
    }

    showLoginForm() {
        document.getElementById('loginForm').style.display = 'block';
        document.getElementById('dashboard').classList.remove('active');
    }

    async loadStats() {
        try {
            const response = await fetch(`${this.apiBase}/stats`);
            const stats = await response.json();
            
            document.getElementById('totalChecks').textContent = stats.total_checks;
            document.getElementById('serverStatus').textContent = stats.server_status;
            document.getElementById('lastCheck').textContent = stats.last_check 
                ? new Date(stats.last_check).toLocaleString() 
                : 'Never';
        } catch (error) {
            console.error('Failed to load stats:', error);
        }
    }

    async loadHealthChecks() {
        try {
            const response = await fetch(`${this.apiBase}/healthchecks`);
            const healthChecks = await response.json();
            
            const tbody = document.getElementById('healthChecksTable');
            tbody.innerHTML = '';
            
            if (healthChecks.length === 0) {
                tbody.innerHTML = '<tr><td colspan="4" style="text-align: center;">No health checks found</td></tr>';
                return;
            }
            
            healthChecks.forEach(check => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${check.id.substring(0, 8)}</td>
                    <td>${check.message}</td>
                    <td>${check.status}</td>
                    <td>${new Date(check.timestamp).toLocaleString()}</td>
                `;
                tbody.appendChild(row);
            });
        } catch (error) {
            console.error('Failed to load health checks:', error);
            document.getElementById('healthChecksTable').innerHTML = 
                '<tr><td colspan="4" style="text-align: center; color: red;">Failed to load health checks</td></tr>';
        }
    }
}

// Initialize admin app
document.addEventListener('DOMContentLoaded', () => {
    new AdminApp();
});