import { useState } from 'react'

export default function App() {
  const [count, setCount] = useState(0)
  return (
    <main style={{ fontFamily: 'system-ui', background: '#0f172a', color: '#e2e8f0', minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16 }}>
      <h1 style={{ fontSize: '2.5rem' }}>Cloud Agent + Vite</h1>
      <p>Clicks: {count}</p>
      <button onClick={() => setCount(c => c + 1)} style={{ padding: '0.5rem 1rem', background: '#1e293b', color: '#e2e8f0', border: '1px solid #334155', borderRadius: 8, cursor: 'pointer' }}>
        Increment
      </button>
    </main>
  )
}
