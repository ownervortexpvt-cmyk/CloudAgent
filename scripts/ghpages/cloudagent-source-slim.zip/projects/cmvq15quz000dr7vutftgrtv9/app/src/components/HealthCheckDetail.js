import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

function HealthCheckDetail() {
  const { id } = useParams();
  const [healthCheck, setHealthCheck] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchHealthCheckDetail();
  }, [id]);

  const fetchHealthCheckDetail = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:3001/api/health-checks/${id}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setHealthCheck(data);
      } else {
        setError('Failed to fetch health check details');
      }
    } catch (error) {
      setError('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getStatusClass = (status) => {
    return status.toLowerCase().replace(/\s+/g, '-');
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString();
  };

  if (loading) {
    return <div className="health-check-detail">Loading health check details...</div>;
  }

  if (error) {
    return (
      <div className="health-check-detail">
        <div className="alert alert-error">{error}</div>
        <button onClick={() => navigate('/')} className="btn btn-secondary">Back to Dashboard</button>
      </div>
    );
  }

  if (!healthCheck) {
    return (
      <div className="health-check-detail">
        <div className="alert alert-error">Health check not found</div>
        <button onClick={() => navigate('/')} className="btn btn-secondary">Back to Dashboard</button>
      </div>
    );
  }

  return (
    <div className="health-check-detail">
      <h2>Health Check Details</h2>
      
      <div className="detail-section">
        <h3>Basic Information</h3>
        <p><strong>User:</strong> {healthCheck.username}</p>
        <p><strong>Status:</strong> <span className={`status ${getStatusClass(healthCheck.status)}`}>{healthCheck.status}</span></p>
        <p><strong>Submitted:</strong> {formatDate(healthCheck.createdAt)}</p>
      </div>

      <div className="detail-section">
        <h3>Health Metrics</h3>
        <p><strong>Temperature:</strong> {healthCheck.temperature ? `${healthCheck.temperature}°F` : 'Not recorded'}</p>
      </div>

      <div className="detail-section">
        <h3>Message/Notes</h3>
        <p>{healthCheck.message || 'No additional notes provided'}</p>
      </div>

      <div className="detail-section">
        <h3>Symptoms</h3>
        <p>{healthCheck.symptoms || 'No symptoms reported'}</p>
      </div>

      <div style={{ marginTop: '30px' }}>
        <button onClick={() => navigate('/')} className="btn btn-secondary">
          Back to Dashboard
        </button>
      </div>
    </div>
  );
}

export default HealthCheckDetail;