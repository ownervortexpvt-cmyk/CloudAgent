import React, { useState } from 'react';

function HealthCheckForm() {
  const [formData, setFormData] = useState({
    status: 'healthy',
    message: '',
    temperature: '',
    symptoms: ''
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess(false);

    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:3001/api/health-checks', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          status: formData.status,
          message: formData.message,
          temperature: formData.temperature ? parseFloat(formData.temperature) : null,
          symptoms: formData.symptoms
        })
      });

      if (response.ok) {
        setSuccess(true);
        // Reset form
        setFormData({
          status: 'healthy',
          message: '',
          temperature: '',
          symptoms: ''
        });
      } else {
        const data = await response.json();
        setError(data.error || 'Failed to submit health check');
      }
    } catch (error) {
      setError('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const statusOptions = [
    { value: 'healthy', label: 'Healthy' },
    { value: 'sick', label: 'Sick' },
    { value: 'recovering', label: 'Recovering' },
    { value: 'exposed', label: 'Exposed' }
  ];

  return (
    <div className="health-check-form">
      <h2>Submit Health Check</h2>
      
      {success && (
        <div className="alert alert-success">
          Health check submitted successfully!
        </div>
      )}
      
      {error && (
        <div className="alert alert-error">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="status">Status</label>
          <select
            id="status"
            name="status"
            value={formData.status}
            onChange={handleChange}
            className="form-control"
            required
          >
            {statusOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="temperature">Temperature (°F)</label>
          <input
            type="number"
            id="temperature"
            name="temperature"
            value={formData.temperature}
            onChange={handleChange}
            className="form-control"
            step="0.1"
            min="95"
            max="110"
          />
        </div>

        <div className="form-group">
          <label htmlFor="message">Message/Notes</label>
          <textarea
            id="message"
            name="message"
            value={formData.message}
            onChange={handleChange}
            className="form-control"
            rows="4"
            placeholder="How are you feeling today?"
          />
        </div>

        <div className="form-group">
          <label htmlFor="symptoms">Symptoms (comma-separated)</label>
          <input
            type="text"
            id="symptoms"
            name="symptoms"
            value={formData.symptoms}
            onChange={handleChange}
            className="form-control"
            placeholder="fever, cough, headache, etc."
          />
        </div>

        <div style={{ marginTop: '30px' }}>
          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? 'Submitting...' : 'Submit Health Check'}
          </button>
          <button type="button" className="btn btn-secondary" onClick={() => {
            setFormData({
              status: 'healthy',
              message: '',
              temperature: '',
              symptoms: ''
            });
            setError('');
            setSuccess(false);
          }}>
            Clear Form
          </button>
        </div>
      </form>
    </div>
  );
}

export default HealthCheckForm;