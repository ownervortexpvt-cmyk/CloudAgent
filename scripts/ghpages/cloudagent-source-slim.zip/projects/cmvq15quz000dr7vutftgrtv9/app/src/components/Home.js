import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

function Home({ user }) {
  const [healthChecks, setHealthChecks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchHealthChecks();
  }, []);

  const fetchHealthChecks = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:3001/api/health-checks', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setHealthChecks(data);
      } else {
        setError('Failed to fetch health checks');
      }
    } catch (error) {
      setError('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getStatusClass = (status) => {
    return status.toLowerCase().replace(/\s+/g, '-');
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  return (
    <div className="health-check-list">
      <h2>Health Check Dashboard</h2>
      <div style={{ marginBottom: '20px' }}>
        <Link to="/health-check" className="btn btn-primary">Submit New Health Check</Link>
      </div>
      
      {error && <div className="alert alert-error">{error}</div>}
      
      {loading ? (
        <p>Loading health checks...</p>
      ) : healthChecks.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '40px' }}>
          <p>No health checks found.</p>
          <Link to="/health-check" className="btn btn-primary">Submit your first health check</Link>
        </div>
      ) : (
        <div>
          <h3>Recent Health Checks</h3>
          {healthChecks.map(check => (
            <div key={check.id} className="health-check-item">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <h4>{check.username}</h4>
                  <span className={`status ${getStatusClass(check.status)}`}>
                    {check.status}
                  </span>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <p><strong>Date:</strong> {formatDate(check.createdAt)}</p>
                  {check.temperature && <p><strong>Temperature:</strong> {check.temperature}°F</p>}
                </div>
              </div>
              {check.message && (
                <p style={{ marginTop: '10px' }}>{check.message}</p>
              )}
              <Link to={`/health-check/${check.id}`} className="btn btn-secondary" style={{ marginTop: '10px' }}>
                View Details
              </Link>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Home;