# Architecture Plan — Health check web application with user-facing interface and admin panel. User app allows users to submit health check status, browse other users' statuses, and view details. Admin panel provides dashboard with real-time statistics, user management, and status monitoring. Backend server provides REST APIs with JWT authentication, CRUD operations, and admin-only endpoints. Database persists all data including users, health check statuses, and audit logs.

## Tech Stack
- Framework: flutter | Runtime: flutter | Language: dart
- Frontend: Flutter Material
- Backend: Node.js/Express or Firebase
- Database: Firebase Firestore or PostgreSQL
- Auth: JWT + bcrypt (or Firebase Auth if Flutter)

## Detected Features
- ✓ auth
- ✓ messaging
- ✓ analytics

## API Endpoints
- POST /api/auth/register
- POST /api/auth/login
- GET /api/auth/me
- POST /api/auth/logout
- GET /api/messages/:userId
- POST /api/messages
- WS /ws/chat
- GET /api/admin/stats

## Data Models
- User { id, email, username, passwordHash, createdAt }
- Message { id, fromUserId, toUserId, content, readAt }

## Folder Structure
```
lib/
  auth/        # Auth flow (login, register, session)
        # Post creation, feed, comments
        # File upload, media storage
  chat/   # DM / chat UI and API
      # Follow, profile pages
  components/  # Reusable UI
  hooks/       # Custom hooks (or providers in Flutter)
  stores/      # State management
  types/       # TypeScript types / Dart models
  api/         # API client

## Security Checklist
- [ ] HTTPS only (enforce in production)
- [ ] CORS configured (allowed origins only)
- [ ] Input validation (Zod for TS, Pydantic for Python, Dart validators for Flutter)
- [ ] Rate limiting (per IP and per user)
- [ ] SQL injection prevention (parameterized queries via Prisma)
- [ ] XSS prevention (output encoding)
- [ ] CSRF tokens (if using cookies for auth)
- [ ] Secrets in .env (never committed to git)
- [ ] File upload validation (type, size, virus scan)
- [ ] JWT expiry + refresh token rotation

## Deployment Plan
1. Build: flutter build apk / aab / web
2. Test: flutter test
3. Deploy: Play Store (Android) / App Store (iOS) / Firebase Hosting (Web)
4. Monitor: error tracking (Sentry) + uptime (BetterUptime)
5. Backups: daily DB snapshots

## Next Steps
1. Call write_file to create each source file (use this plan as a guide)
2. Call install_package to install dependencies
3. Call run_project to start the dev server
4. Call inspect_logs to verify it works
