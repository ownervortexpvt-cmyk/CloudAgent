const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const sqlite3 = require('sqlite3').verbose();
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

app.use(cors());
app.use(express.json());

// Initialize SQLite database
const db = new sqlite3.Database('./db/healthcheck.db');

// Create tables
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    username TEXT UNIQUE NOT NULL,
    passwordHash TEXT NOT NULL,
    role TEXT DEFAULT 'user',
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS health_checks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    userId INTEGER NOT NULL,
    status TEXT NOT NULL,
    message TEXT,
    temperature REAL,
    symptoms TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userId) REFERENCES users (id)
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS admin_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    adminId INTEGER,
    action TEXT NOT NULL,
    targetId INTEGER,
    details TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (adminId) REFERENCES users (id)
  )`);
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'OK', message: 'Healthcheck server is running', timestamp: new Date().toISOString() });
});

// Auth endpoints
app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, username, password } = req.body;
    
    if (!email || !username || !password) {
      return res.status(400).json({ error: 'Email, username, and password are required' });
    }

    // Check if user already exists
    db.get('SELECT * FROM users WHERE email = ? OR username = ?', [email, username], async (err, user) => {
      if (err) {
        return res.status(500).json({ error: 'Database error' });
      }
      
      if (user) {
        return res.status(400).json({ error: 'User already exists' });
      }

      // Hash password
      const passwordHash = await bcrypt.hash(password, 10);
      
      // Create user
      db.run('INSERT INTO users (email, username, passwordHash) VALUES (?, ?, ?)', 
        [email, username, passwordHash], function(err) {
          if (err) {
            return res.status(500).json({ error: 'Failed to create user' });
          }
          
          const token = jwt.sign({ userId: this.lastID, role: 'user' }, JWT_SECRET, { expiresIn: '24h' });
          res.json({ token, user: { id: this.lastID, email, username, role: 'user' } });
        });
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
      if (err) {
        return res.status(500).json({ error: 'Database error' });
      }
      
      if (!user) {
        return res.status(400).json({ error: 'Invalid credentials' });
      }

      const isValid = await bcrypt.compare(password, user.passwordHash);
      if (!isValid) {
        return res.status(400).json({ error: 'Invalid credentials' });
      }

      const token = jwt.sign({ userId: user.id, role: user.role }, JWT_SECRET, { expiresIn: '24h' });
      res.json({ 
        token, 
        user: { 
          id: user.id, 
          email: user.email, 
          username: user.username, 
          role: user.role 
        } 
      });
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Middleware to verify JWT token
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

// Middleware to check admin role
const requireAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
};

// Health check endpoints
app.get('/api/health-checks', authenticateToken, (req, res) => {
  const query = req.user.role === 'admin' 
    ? 'SELECT hc.*, u.username FROM health_checks hc JOIN users u ON hc.userId = u.id ORDER BY hc.createdAt DESC'
    : 'SELECT hc.*, u.username FROM health_checks hc JOIN users u ON hc.userId = u.id WHERE hc.userId = ? ORDER BY hc.createdAt DESC';
  
  const params = req.user.role === 'admin' ? [] : [req.user.userId];
  
  db.all(query, params, (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(rows);
  });
});

app.post('/api/health-checks', authenticateToken, (req, res) => {
  const { status, message, temperature, symptoms } = req.body;
  
  if (!status) {
    return res.status(400).json({ error: 'Status is required' });
  }

  db.run('INSERT INTO health_checks (userId, status, message, temperature, symptoms) VALUES (?, ?, ?, ?, ?)',
    [req.user.userId, status, message, temperature, symptoms], function(err) {
      if (err) {
        return res.status(500).json({ error: 'Failed to create health check' });
      }
      res.json({ id: this.lastID, status, message, temperature, symptoms });
    });
});

// Admin endpoints
app.get('/api/admin/stats', authenticateToken, requireAdmin, (req, res) => {
  const stats = {};
  
  // Total users
  db.get('SELECT COUNT(*) as count FROM users', (err, row) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    stats.totalUsers = row.count;
    
    // Total health checks
    db.get('SELECT COUNT(*) as count FROM health_checks', (err, row) => {
      if (err) return res.status(500).json({ error: 'Database error' });
      stats.totalHealthChecks = row.count;
      
      // Recent health checks (last 24 hours)
      db.get('SELECT COUNT(*) as count FROM health_checks WHERE createdAt >= datetime("now", "-24 hours")', 
        (err, row) => {
          if (err) return res.status(500).json({ error: 'Database error' });
          stats.recentHealthChecks = row.count;
          
          // Users by status
          db.all('SELECT status, COUNT(*) as count FROM health_checks GROUP BY status', (err, rows) => {
            if (err) return res.status(500).json({ error: 'Database error' });
            stats.byStatus = rows.reduce((acc, row) => {
              acc[row.status] = row.count;
              return acc;
            }, {});
            
            res.json(stats);
          });
        });
    });
  });
});

app.get('/api/admin/users', authenticateToken, requireAdmin, (req, res) => {
  db.all('SELECT id, email, username, role, createdAt FROM users ORDER BY createdAt DESC', 
    (err, rows) => {
      if (err) {
        return res.status(500).json({ error: 'Database error' });
      }
      res.json(rows);
    });
});

app.get('/api/admin/health-checks', authenticateToken, requireAdmin, (req, res) => {
  db.all('SELECT hc.*, u.username FROM health_checks hc JOIN users u ON hc.userId = u.id ORDER BY hc.createdAt DESC',
    (err, rows) => {
      if (err) {
        return res.status(500).json({ error: 'Database error' });
      }
      res.json(rows);
    });
});

app.delete('/api/admin/users/:id', authenticateToken, requireAdmin, (req, res) => {
  const userId = req.params.id;
  
  // Log admin action
  db.run('INSERT INTO admin_logs (adminId, action, targetId, details) VALUES (?, ?, ?, ?)',
    [req.user.userId, 'delete_user', userId, `Deleted user ${userId}`], (err) => {
      if (err) console.error('Failed to log admin action:', err);
    });
  
  db.run('DELETE FROM users WHERE id = ?', [userId], function(err) {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    if (this.changes === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json({ message: 'User deleted successfully' });
  });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Health check available at: http://localhost:${PORT}/health`);
});