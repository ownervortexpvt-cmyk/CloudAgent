# ⚡ CloudAgent — AI Multi-Agent App Builder

**Public web release (GitHub Pages):** https://mdhonabali02.github.io/cloudagent-web/

CloudAgent is an AI app-builder SaaS where one instruction deploys a coordinated
swarm of up to 1,000 AI agents that plans, codes, reviews and ships real
software — with a real Linux terminal, GitHub two-way sync, APK / .exe exports,
template marketplace, live collaboration, custom domains and UPI payments via
Razorpay.

- 📄 Public site: https://cloudagent-web.netlify.app/
- 📧 Contact: mdhonabali61@gmail.com
- ⚡ Accounts are open to everyone — email us and we'll send your workspace link (a security key screen protects the builder).

> This repository contains ONLY the public static release site. The platform
> source lives in a separate private repository.
