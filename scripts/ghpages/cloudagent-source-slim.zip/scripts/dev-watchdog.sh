#!/usr/bin/env bash
# v79 dev-watchdog — the sandbox has 4GB RAM and no swap. When the owner runs
# several builds (flutter/gradle/dotnet/vite) the next-server heap can balloon
# (seen: 2.1GB RSS) and the kernel OOM-kills it → every request 502s until a
# manual restart. This watchdog:
#   1. checks :3000 every 30s (2 consecutive failures = down)
#   2. kills orphaned project-run processes (cwd inside projects/) first —
#      they hold RAM + ports after their parent died
#   3. cold-restarts next dev with a hard heap cap (NODE_OPTIONS max-old-space)
#   4. waits 60s before probing again (cold compile needs time)
# Single-instance (own lock, stale takeover after 30 min). Run detached:
#   nohup setsid bash scripts/dev-watchdog.sh </dev/null >/dev/null 2>&1 &
set -u
BASE=/home/z/my-project
LOG=$BASE/dev-watchdog.log
LOCK=$BASE/.dev-watchdog.lock
STALE=$((2 * 60))           # seconds — the live loop touches the lock every cycle, so a lock older than 2 min = dead watchdog
PROBE_TIMEOUT=20            # cold compiles can be slow — don't false-positive
HEAP_CAP=1280               # MB — next-server JS heap ceiling (host guard)

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG"; }

if [ -d "$LOCK" ]; then
  AGE=$(( $(date +%s) - $(stat -c %Y "$LOCK" 2>/dev/null || echo 0) ))
  if [ "$AGE" -gt "$STALE" ]; then
    log "stale lock (${AGE}s) — taking over"
    rm -rf "$LOCK"
  else
    exit 0   # another watchdog already running
  fi
fi
mkdir -p "$LOCK"
trap 'rm -rf "$LOCK"' EXIT

probe() { curl -s -o /dev/null --max-time "$PROBE_TIMEOUT" "http://localhost:3000/api/lock"; }
probe_socket() { curl -s -o /dev/null --max-time 8 "http://localhost:3001/" ; }

# v101: guard the :3001 socket service too. The .zscripts/dev.sh supervisor
# normally owns this, but when it dies (sandbox reapers kill orphaned
# supervisors) the watchdog is the only survivor — a dead socket means the
# realtime agent features die silently. Same respawn logic as dev.sh's
# start_socket, kept in sync.
start_socket() {
  pkill -f "bun --hot index.ts" 2>/dev/null
  if [ ! -d "$BASE/mini-services/agent-service/node_modules/socket.io" ]; then
    log "agent-service deps missing — installing"
    (cd "$BASE/mini-services/agent-service" && bun install >> "$BASE/socket-service.log" 2>&1)
  fi
  log "starting socket service (:3001)"
  setsid nohup bash -c "cd '$BASE/mini-services/agent-service' && exec bun --hot index.ts >> '$BASE/socket-service.log' 2>&1" </dev/null >/dev/null 2>&1 &
}

# v86: is the canonical .zscripts/dev.sh supervisor alive? When it is, it
# OWNS :3000 recovery — two restarters cold-rm .next and respawn next dev
# against each other (port fights, double restarts). The watchdog then stays
# monitor-only and leaves recovery to the supervisor.
supervisor_alive() {
  for pid in $(ls /proc 2>/dev/null | grep -E '^[0-9]+$'); do
    [ "$pid" = "$$" ] && continue
    cmd=$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null)
    case "$cmd" in *".zscripts/dev.sh"*) return 0 ;; esac
  done
  return 1
}

# v86 FIX (owner: "Run problem"): `pkill -f "next dev"` also killed GENERATED
# apps running `next dev -p 4xxx` inside projects/. Platform recovery must
# only kill the PLATFORM's own next processes — cwd == $BASE exactly (a
# generated app's cwd lives under $BASE/projects/<id>).
kill_platform_next() {
  local killed=0
  for pid in $(ls /proc 2>/dev/null | grep -E '^[0-9]+$'); do
    [ "$pid" = "$$" ] && continue
    cwd=$(readlink "/proc/$pid/cwd" 2>/dev/null) || continue
    [ "$cwd" = "$BASE" ] || continue
    cmd=$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null)
    case "$cmd" in
      *"next dev"*|*next-server*)
        log "killing platform next process $pid ($cmd)"
        kill -9 "$pid" 2>/dev/null && killed=$((killed+1))
        ;;
    esac
  done
  [ "$killed" -gt 0 ] && log "killed $killed platform next process(es)"
}

# kill processes whose cwd lives inside projects/ (orphaned vite/dotnet/flutter/
# gradle runs from a dead next-server — they keep eating RAM and holding ports).
# v86 guards: only TRUE orphans (ppid == 1) OLDER than 3 minutes — the old
# version killed LIVE user apps and MID-FLIGHT npm installs whenever the
# platform had a bad 60s window (false :3000 DOWN), which corrupted
# node_modules and looked exactly like the owner's "Run problem".
kill_project_children() {
  local killed=0
  for pid in $(ls /proc 2>/dev/null | grep -E '^[0-9]+$'); do
    [ "$pid" = "$$" ] && continue
    ppid=$(awk '{print $4}' "/proc/$pid/stat" 2>/dev/null) || continue
    [ "$ppid" = "1" ] || continue
    # age in seconds: (uptime - starttime/100)
    read -r UPTIME REST < /proc/uptime 2>/dev/null || continue
    START=$(awk '{print $22}' "/proc/$pid/stat" 2>/dev/null) || continue
    AGE=$(awk -v u="$UPTIME" -v s="$START" 'BEGIN { printf "%d", u - s/100 }')
    [ "$AGE" -gt 180 ] || continue
    cwd=$(readlink "/proc/$pid/cwd" 2>/dev/null) || continue
    case "$cwd" in
      "$BASE/projects/"*)
        cmd=$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null | head -c 80)
        log "killing orphan $pid (age=${AGE}s, cwd=$cwd) $cmd"
        kill -9 "$pid" 2>/dev/null && killed=$((killed+1))
        ;;
    esac
  done
  [ "$killed" -gt 0 ] && log "killed $killed orphan(s)"
}

# v102.2 ZOMBIE SWEEP (same rule as .zscripts/dev.sh boot): a container
# recycle resurrects untracked base-image files (the v91/v100-removed Drive
# system). Every watchdog start re-deletes them — the routes can never serve.
for z in src/app/api/gdrive src/app/api/sdks/drive src/lib/gdrive.ts scripts/e2e-v80-publish-gdrive.js; do
  [ -e "$BASE/$z" ] && { rm -rf "$BASE/$z"; log "zombie sweep: removed $z (recycle resurrected it)"; }
done

log "watchdog started (pid $$, heap cap ${HEAP_CAP}MB)"

FAILS=0
SOCKET_FAILS=0
while true; do
  sleep 30
  touch "$LOCK"   # heartbeat — proves this watchdog is alive

  # v101 — :3001 socket guard (independent of the web loop; monitor-only
  # while the .zscripts/dev.sh supervisor is alive, same rule as the web)
  if probe_socket; then
    SOCKET_FAILS=0
  else
    SOCKET_FAILS=$((SOCKET_FAILS+1))
    log "socket probe failed ($SOCKET_FAILS/2)"
    if [ "$SOCKET_FAILS" -ge 2 ] && ! supervisor_alive; then
      SOCKET_FAILS=0
      start_socket
    fi
  fi

  if probe; then
    FAILS=0
    continue
  fi
  FAILS=$((FAILS+1))
  log "probe failed ($FAILS/2)"
  [ "$FAILS" -lt 2 ] && continue

  # ---- server is DOWN: recover ----
  # v86: when the canonical supervisor runs, leave recovery to it — the old
  # double-recovery (watchdog + supervisor both cold-rm .next and respawn
  # next dev) raced itself into repeated DOWN cycles and killed user apps.
  if supervisor_alive; then
    log ":3000 DOWN — .zscripts/dev.sh supervisor is alive, leaving recovery to it (monitor-only)"
    FAILS=0
    continue
  fi
  log ":3000 DOWN — recovering (no supervisor alive)"
  kill_project_children
  kill_platform_next
  sleep 2
  # v101 SPEED MODE: with the .prodmode marker + a production build present,
  # recovery starts `next start` (prod) instead of `next dev` — same RAM/
  # latency benefits as the supervisor's prod branch. Cold .next clear only
  # happens in the dev path (a prod build must never be wiped).
  if [ -f "$BASE/.prodmode" ] && [ -f "$BASE/.next/BUILD_ID" ]; then
    cd "$BASE" || exit 1
    NODE_OPTIONS="--max-old-space-size=${HEAP_CAP}" setsid nohup \
      bash -c "cd '$BASE' && PATH='$BASE/node_modules/.bin:$PATH' next start -p 3000 2>&1 | tee -a dev.log" </dev/null >/dev/null 2>&1 &
    log "next start respawned (production build, heap capped at ${HEAP_CAP}MB)"
    FAILS=0
    sleep 60
    continue
  fi
  # cold start: stale Turbopack cache caused the TerminalPane ChunkLoadError
  # before; a fresh .next on every recovery keeps chunks consistent
  rm -rf "$BASE/.next"
  cd "$BASE" || exit 1
  NODE_OPTIONS="--max-old-space-size=${HEAP_CAP}" setsid nohup \
    bash -c "cd '$BASE' && PATH='$BASE/node_modules/.bin:$PATH' next dev -p 3000 2>&1 | tee -a dev.log" </dev/null >/dev/null 2>&1 &
  log "next dev respawned (detached, heap capped at ${HEAP_CAP}MB)"
  FAILS=0
  sleep 60   # boot + first compile window before probing again
done
