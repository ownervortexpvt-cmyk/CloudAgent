#!/usr/bin/env python3
"""
e2e-v123-features.py — the 5-feature release suite (world's-strongest batch).

Covers, over REAL HTTP on the REAL server:
  0. PRIVATE GATE      — no key 401s APIs + redirects pages; wrong key 401;
                          right key (header) passes; /api/gate sets a cookie
                          that passes page requests.
  1. GITHUB PER-USER   — token saved per user; other user CANNOT see/use it;
                          real push E2E against github.com when a live PAT is
                          provided via CA_GITHUB_PAT (repo created + pushed +
                          deleted).
  2. APK BUTTON API    — /api/publish target=apk on a non-Flutter project
                          fails HONESTLY; web target produces a downloadUrl.
  3. MARKETPLACE       — publish (snapshot) → browse → search → install as a
                          SECOND user → files land in THEIR new project;
                          paid listing installs 402 honestly; unpublish.
  4. COLLABORATION     — invite by email; collaborator gains real access;
                          presence shows both users; file-save events flow
                          to the other user's sync pull; remove works.
  5. CUSTOM DOMAINS    — claim → duplicate 409 → invalid 400 → verify honest
                          DNS failure → (DB-assisted) verified domain SERVES
                          the project through the middleware host rewrite.

Usage: python3 scripts/e2e-v123-features.py
"""
import json
import os
import sqlite3
import sys
import time
import urllib.request
import urllib.error

BASE = 'http://localhost:3000'
GATE = 'CA-X-MONA-9173'
DB = '/home/z/my-project/db/custom.db'
STAMP = str(int(time.time()))
PAT = os.environ.get('CA_GITHUB_PAT', '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').strip()

PASS, FAIL = [], []

def check(name, cond, detail=''):
    (PASS if cond else FAIL).append(name)
    print(f"  {'✅' if cond else '❌'} {name}" + (f' — {detail}' if detail and not cond else ''))
    return cond

def req(method, path, body=None, token=None, headers=None, raw=False, timeout=90, no_gate=False):
    data = json.dumps(body).encode() if body is not None else None
    h = {'Content-Type': 'application/json'}
    if not no_gate: h['x-ca-gate'] = GATE
    if token: h['x-ca-lock'] = token
    if headers: h.update(headers)
    r = urllib.request.Request(BASE + path, data=data, method=method, headers=h)
    try:
        with urllib.request.urlopen(r, timeout=timeout) as resp:
            payload = resp.read()
            if raw: return resp.status, payload, dict(resp.headers)
            try: return resp.status, json.loads(payload), dict(resp.headers)
            except Exception: return resp.status, {'_raw': payload.decode('utf-8', 'replace')[:300]}, dict(resp.headers)
    except urllib.error.HTTPError as e:
        payload = e.read()
        try: return e.code, json.loads(payload), dict(e.headers)
        except Exception: return e.code, {'_raw': payload.decode('utf-8', 'replace')[:300]}, dict(e.headers)
    except Exception as e:
        return 0, {'error': str(e)}, {}

def login(email, password):
    s, d, _ = req('POST', '/api/auth/login', {'email': email, 'password': password})
    return (d or {}).get('token')

print('════════ v123 — FEATURE E2E ════════')

# ══ 0. PRIVATE GATE ═══════════════════════════════════════════════════════
print('— 0. private gate')
s, d, _ = req('GET', '/api/projects', no_gate=True)
check('no gate key → API 401', s == 401 and d.get('limit') == 'gate', f'{s} {str(d)[:100]}')
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k): return None
opener = urllib.request.build_opener(NoRedirect)
rr = urllib.request.Request(BASE + '/login', headers={'x-ca-gate': 'absent'})
try:
    with opener.open(rr, timeout=20) as resp:
        redirected = False
except urllib.error.HTTPError as e:
    redirected = e.code in (301, 302, 303, 307) and '/gate' in str(e.headers.get('Location', ''))
except Exception:
    redirected = False
check('no gate key → page redirects to /gate', redirected)
s, d, _ = req('POST', '/api/gate', {'key': 'totally-wrong-key'}, no_gate=True)
check('wrong key → 401 honest message', s == 401 and 'private' in str(d.get('error', '')).lower() or s == 401, f'{s}')
s, d, hdrs = req('POST', '/api/gate', {'key': GATE}, no_gate=True)
cookie_ok = s == 200 and d.get('ok')
if cookie_ok:
    rr = urllib.request.Request(BASE + '/api/gate')
    with urllib.request.urlopen(rr, timeout=15) as resp: pass
    import http.client
    conn = http.client.HTTPConnection('localhost', 3000, timeout=15)
    conn.request('POST', '/api/gate', json.dumps({'key': GATE}), {'Content-Type': 'application/json'})
    r2 = conn.getresponse(); r2.read()
    cookie_ok = any('ca_gate=' in (v or '') for v in r2.msg.get_all('Set-Cookie') or [])
    conn.close()
check('right key → ok + cookie set', cookie_ok, f'{s} {str(d)[:80]}')
s, d, _ = req('GET', '/api/version', no_gate=True)
check('/api/version stays public (PWA banner)', s == 200, str(s))

# ══ users ═════════════════════════════════════════════════════════════════
s, d, _ = req('POST', '/api/auth/login', {'email': 'qa-admin115@qa.local', 'password': 'qatester115'})
OWNER = d.get('token')
check('QA admin login', s == 200 and OWNER, str(s))
s, d, _ = req('POST', '/api/admin/panel/session', {'pin': '1000391619244862'}, token=OWNER)
ROOM = d.get('token', '')
check('control room unlocked (for plan upgrades)', s == 200 and ROOM, f'{s} {str(d)[:80]}')

A = {'name': 'Alice V123', 'email': f'alice-{STAMP}@cloudagent.test', 'password': 'alice-pass-1'}
B = {'name': 'Bob V123', 'email': f'bob-{STAMP}@cloudagent.test', 'password': 'bob-pass-1'}
s, d, _ = req('POST', '/api/auth/register', A)
check('register Alice', s == 200 and d.get('ok'), f'{s} {str(d)[:100]}')
s, d, _ = req('POST', '/api/auth/register', B)
check('register Bob', s == 200 and d.get('ok'), f'{s} {str(d)[:100]}')
ALICE = login(A['email'], A['password'])
BOB = login(B['email'], B['password'])
check('Alice + Bob tokens', bool(ALICE) and bool(BOB))

# v115 business model: free accounts build only during BBD — upgrade both to
# a paid plan exactly like the business suite does.
s2, d2, _ = req('GET', '/api/admin/users', token=OWNER)
users = {u.get('email'): u.get('id') for u in d2.get('users', [])} if isinstance(d2.get('users'), list) else {}
for email, tok in [(A['email'], ALICE), (B['email'], BOB)]:
    uid = users.get(email)
    if uid:
        s2, d2, _ = req('POST', '/api/auth/plan', {'userId': uid, 'plan': 'ultra'}, token=OWNER, headers={'x-ca-admin': ROOM})
        check(f'{email.split("@")[0]} upgraded to ultra (business model)', s2 == 200 and d2.get('ok'), f'{s2} {str(d2)[:80]}')

# projects
s, d, _ = req('POST', '/api/projects', {'name': f'V123-App-{STAMP}', 'language': 'html'}, token=ALICE)
APROJ = d.get('project', {}).get('id') or d.get('id')
check('Alice project created', s == 200 and APROJ, f'{s} {str(d)[:120]}')
s, d, _ = req('POST', '/api/projects', {'name': f'V123-BobApp-{STAMP}', 'language': 'html'}, token=BOB)
BPROJ = d.get('project', {}).get('id') or d.get('id')
check('Bob project created', s == 200 and BPROJ, f'{s}')
for path, content in [('index.html', '<h1>Market App</h1><p>v123</p>'), ('style.css', 'body{font-family:sans-serif}')]:
    s, d, _ = req('POST', '/api/files', {'projectId': APROJ, 'path': path, 'content': content}, token=ALICE)
check('Alice project files written', s == 200)

# ══ 1. GITHUB PER-USER ════════════════════════════════════════════════════
print('— 1. github per-user')
s, d, _ = req('GET', '/api/github')
check('github accounts signed-out → 401', s == 401, str(s))
s, d, _ = req('POST', '/api/github', {'name': 'Alice GH', 'token': 'ghp_fake_invalid_token_for_negative_test'}, token=ALICE)
GHID = d.get('account', {}).get('id')
check('Alice saves a (fake) PAT → encrypted row', s == 200 and GHID, f'{s} {str(d)[:100]}')
s, d, _ = req('GET', '/api/github', token=BOB)
check('Bob sees ZERO of Alice GitHub accounts', s == 200 and all(a['id'] != GHID for a in d.get('accounts', [])), str(s)[:100])
s, d, _ = req('POST', '/api/github/operations', {'action': 'listRepos', 'accountId': GHID}, token=BOB)
check('Bob CANNOT operate Alice GitHub (404)', s == 404, f'{s} {str(d)[:80]}')
s, d, _ = req('POST', '/api/github/operations', {'action': 'listRepos', 'accountId': GHID}, token=ALICE)
check('Alice fake-PAT listRepos → honest 502', s == 502, f'{s} {str(d)[:80]}')

if PAT and not PAT.startswith('ghp_x'):
    s, d, _ = req('POST', '/api/github', {'name': 'Owner Live PAT', 'token': PAT}, token=OWNER)
    OGHID = d.get('account', {}).get('id')
    if OGHID:
        s, d, _ = req('POST', '/api/github/operations', {'action': 'listRepos', 'accountId': OGHID}, token=OWNER)
        check('LIVE PAT listRepos → ok', s == 200 and d.get('ok'), f'{s} {str(d)[:100]}')
        repo = f'cloudagent-e2e-{STAMP}'
        s, d, _ = req('POST', '/api/github/operations', {'action': 'createRepo', 'accountId': OGHID, 'name': repo, 'private': True}, token=OWNER)
        ok_create = s == 200 and d.get('ok')
        check(f'LIVE createRepo {repo}', ok_create, f'{s} {str(d)[:150]}')
        if ok_create:
            if not APROJ:
                s, d, _ = req('POST', '/api/projects', {'name': f'V123-OwnerPush-{STAMP}', 'language': 'html'}, token=OWNER)
                APROJ = d.get('project', {}).get('id') or d.get('id')
                req('POST', '/api/files', {'projectId': APROJ, 'path': 'index.html', 'content': '<h1>push test</h1>'}, token=OWNER)
            s, d, _ = req('POST', '/api/github/operations', {'action': 'push', 'accountId': OGHID, 'projectId': APROJ, 'repo': f'mdhonabali61-blip/{repo}', 'message': 'v123 e2e push'}, token=OWNER, timeout=240)
            check('LIVE push project → PUSH_OK', s == 200 and d.get('ok'), f'{s} {str(d)[:200]}')
            # cleanup: delete the test repo via API
            cleanup = urllib.request.Request(f'https://api.github.com/repos/mdhonabali61-blip/{repo}', method='DELETE',
                                             headers={'Authorization': f'Bearer {PAT}', 'User-Agent': 'CloudAgent-E2E'})
            try:
                with urllib.request.urlopen(cleanup, timeout=30) as r: print(f'  🧹 test repo {repo} deleted ({r.status})')
            except Exception as e: print(f'  ⚠️ cleanup delete failed: {e}')
    else:
        check('LIVE PAT saved', False, str(d)[:100])

# ══ 2. APK BUTTON API ═════════════════════════════════════════════════════
print('— 2. apk button api')
s, d, _ = req('POST', '/api/publish', {'projectId': APROJ, 'target': 'apk'}, token=ALICE, timeout=120)
check('apk on non-Flutter → honest Flutter error', s == 200 and 'Flutter' in str(d.get('error', '')), f'{s} {str(d)[:120]}')
s, d, _ = req('POST', '/api/publish', {'projectId': APROJ, 'target': 'web'}, token=ALICE, timeout=180)
check('web target → ok + downloadUrl (button pipeline)', s == 200 and d.get('ok') and d.get('downloadUrl', '').startswith('/api/publish?id='), f'{s} {str(d)[:150]}')
if d.get('downloadUrl'):
    s2, raw2, h2 = req('GET', d['downloadUrl'], token=ALICE, raw=True, timeout=120)
    check('artifact download streams a zip', s2 == 200 and raw2[:2] == b'PK', f'{s2} {len(raw2)}b')

# ══ 3. MARKETPLACE ════════════════════════════════════════════════════════
print('— 3. marketplace')
s, d, _ = req('POST', '/api/marketplace', {'projectId': APROJ, 'title': f'V123 Sample {STAMP}', 'description': 'A tiny shared app', 'category': 'tools', 'priceInr': 0}, token=ALICE)
LID = d.get('listing', {}).get('id')
check('Alice publishes free listing (snapshot)', s == 200 and LID, f'{s} {str(d)[:120]}')
s, d, _ = req('POST', '/api/marketplace', {'projectId': BPROJ, 'title': 'X', 'description': '', 'category': 'apps'}, token=ALICE)
check('Alice CANNOT publish Bob project (403)', s == 403, str(s))
s, d, _ = req('POST', '/api/marketplace', {'projectId': 'no-such-project-id', 'title': 'Bad', 'priceInr': 0}, token=ALICE)
check('packaging nonexistent project → 403', s == 403, f'{s} {str(d)[:80]}')
s, d, _ = req('GET', '/api/marketplace', token=BOB)
check('Bob browses → sees Alice listing', s == 200 and any(l['id'] == LID for l in d.get('listings', [])), str(s))
s, d, _ = req('GET', f'/api/marketplace?q=v123+sample', token=BOB)
check('search finds it', s == 200 and any(l['id'] == LID for l in d.get('listings', [])), str(s)[:80])
s, d, _ = req('POST', '/api/marketplace/install', {'listingId': LID}, token=BOB)
INSTALLED = d.get('projectId')
check('Bob installs → NEW project for Bob', s == 200 and d.get('ok') and INSTALLED and INSTALLED != APROJ, f'{s} {str(d)[:120]}')
s, d, _ = req('GET', f'/api/files?projectId={INSTALLED}&path=index.html', token=BOB)
check('installed project has the files', s == 200 and 'Market App' in str(d.get('content', '')), f'{s} {str(d)[:100]}')
s, d, _ = req('POST', '/api/marketplace/install', {'listingId': LID}, token=ALICE)
check('seller re-installs own listing (allowed)', s == 200 and d.get('ok'), f'{s} {str(d)[:80]}')

# paid listing — honest 402 until Razorpay keys
s, d, _ = req('POST', '/api/marketplace', {'projectId': APROJ, 'title': f'V123 Paid {STAMP}', 'description': 'paid', 'priceInr': 499}, token=ALICE)
PAID = d.get('listing', {}).get('id')
check('Alice publishes ₹499 listing', s == 200 and PAID, f'{s}')
s, d, _ = req('POST', '/api/marketplace/install', {'listingId': PAID}, token=BOB)
check('paid install → 402 payment_required (honest)', s == 402 and d.get('limit') == 'payment_required', f'{s} {str(d)[:100]}')
s, d, _ = req('DELETE', f'/api/marketplace?id={PAID}', token=BOB)
check('Bob cannot remove Alice listing (403)', s == 403, str(s))
s, d, _ = req('DELETE', f'/api/marketplace?id={PAID}', token=ALICE)
check('Alice unpublishes her listing', s == 200, str(s))

# ══ 4. COLLABORATION ══════════════════════════════════════════════════════
print('— 4. collaboration')
s, d, _ = req('GET', f'/api/projects/{APROJ}/collab', token=ALICE)
check('collab list empty initially', s == 200 and d.get('collaborators') == [] and d.get('isOwner'), str(s))
s, d, _ = req('POST', f'/api/projects/{APROJ}/collab', {'email': B['email'], 'role': 'editor'}, token=BOB)
check('Bob CANNOT invite on Alice project (403)', s == 403, str(s))
s, d, _ = req('POST', f'/api/projects/{APROJ}/collab', {'email': 'nobody-here@nowhere.test', 'role': 'editor'}, token=ALICE)
check('invite unregistered email → 404 honest', s == 404, f'{s} {str(d)[:80]}')
s, d, _ = req('POST', f'/api/projects/{APROJ}/collab', {'email': B['email'], 'role': 'editor'}, token=ALICE)
check('Alice invites Bob → ok', s == 200 and d.get('ok'), f'{s} {str(d)[:100]}')
s, d, _ = req('POST', f'/api/projects/{APROJ}/collab', {'email': B['email'], 'role': 'editor'}, token=ALICE)
check('duplicate invite → 409', s == 409, str(s))
s, d, _ = req('GET', f'/api/files?projectId={APROJ}&path=index.html', token=BOB)
check('Bob now READS Alice project files (collab access)', s == 200 and 'Market App' in str(d.get('content', '')), f'{s}')
s, d, _ = req('POST', '/api/projects', {'name': 'x'}, token=BOB)
s, d, _ = req('DELETE', f'/api/projects/{APROJ}?hard=1', token=BOB)
check('Bob still cannot DELETE Alice project', s in (403, 404), str(s))

# presence + events
s, d, _ = req('POST', f'/api/projects/{APROJ}/collab/sync', {'tab': 'index.html', 'since': 0}, token=ALICE)
check('Alice heartbeat → online includes her', s == 200 and any(p['userId'] for p in d.get('online', [])), str(d)[:80])
s, d, _ = req('POST', '/api/files', {'projectId': APROJ, 'path': 'collab.md', 'content': 'written by bob'}, token=BOB)
check('Bob writes a file in Alice project (collab editor)', s == 200, f'{s}')
s, d, _ = req('POST', f'/api/projects/{APROJ}/collab/sync', {'tab': '', 'since': 0}, token=ALICE)
evs = d.get('events', [])
check('Alice sync sees Bob file event', s == 200 and any(e['path'] == 'collab.md' and e['byName'] == 'Bob V123' for e in evs), str(d)[:160])
s, d, _ = req('GET', f'/api/projects/{APROJ}/collab', token=ALICE)
colls = d.get('collaborators', []) if isinstance(d.get('collaborators'), list) else []
check('collab list shows Bob', s == 200 and any(c['email'] == B['email'] for c in colls), str(s)[:100])
bob_uid = next((c['userId'] for c in colls if c['email'] == B['email']), '')
s, d, _ = req('DELETE', f'/api/projects/{APROJ}/collab?userId={bob_uid}', token=ALICE)
check('Alice removes Bob', s == 200, str(s))
s, d, _ = req('GET', f'/api/files?projectId={APROJ}&path=collab.md', token=BOB)
check('removed Bob loses access (403)', s == 403, str(s))

# ══ 5. CUSTOM DOMAINS ═════════════════════════════════════════════════════
print('— 5. custom domains')
DOM = f'shop-{STAMP}.example.com'
s, d, _ = req('POST', '/api/custom-domains', {'domain': 'not a domain', 'projectId': APROJ}, token=ALICE)
check('invalid domain → 400', s == 400, str(s))
s, d, _ = req('POST', '/api/custom-domains', {'domain': DOM, 'projectId': APROJ}, token=BOB)
check('Bob CANNOT claim on Alice project (403)', s == 403, str(s))
s, d, _ = req('POST', '/api/custom-domains', {'domain': DOM, 'projectId': APROJ}, token=ALICE)
DOMID = d.get('domain', {}).get('id')
VTOKEN = d.get('domain', {}).get('verifyToken')
check('Alice claims domain → token issued', s == 200 and DOMID and VTOKEN, f'{s} {str(d)[:120]}')
s, d, _ = req('POST', '/api/custom-domains', {'domain': DOM, 'projectId': BPROJ}, token=BOB)
check('duplicate claim → 409', s == 409, str(s))
s, d, _ = req('POST', '/api/custom-domains/verify', {'id': DOMID}, token=ALICE)
check('verify without DNS → honest pending', s in (200, 201) and d.get('verified') is False, f'{s} {str(d)[:140]}')
s, d, _ = req('GET', f'/api/custom-domains/lookup?host={DOM}', no_gate=True)
check('lookup → unmapped while unverified', s == 200 and d.get('mapped') is False and 'verify' in str(d.get('reason', '')).lower(), str(d)[:140])
s, d, _ = req('GET', '/api/custom-domains', token=ALICE)
check('domain list includes claim + DNS records', s == 200 and any(x['domain'] == DOM and x.get('dns') for x in d.get('domains', [])), str(s)[:100])

# DB-assisted live-serving check: mark verified, restart the site map (30s TTL
# bypassed by first hit after a fresh process — accept up to 35s wait), then
# request with the custom Host header. The middleware should rewrite to the
# project's preview. The project is STOPPED, so we expect the auto-start to
# kick in; poll a few times and accept any non-redirect HTML for the app.
try:
    con = sqlite3.connect(DB)
    con.execute("UPDATE CustomDomain SET verified = 1, status = 'verified' WHERE id = ?", (DOMID,))
    con.commit(); con.close()
    print('  (db-assisted) domain marked verified for the serving test')
except Exception as e:
    print(f'  ⚠️ db assist failed: {e}')

serving = False
for attempt in range(6):
    r = urllib.request.Request(BASE + '/', headers={'Host': DOM, 'x-ca-gate': GATE})
    try:
        with urllib.request.urlopen(r, timeout=20) as resp:
            body = resp.read().decode('utf-8', 'replace')
            serving = resp.status == 200 and ('<html' in body.lower())
            if serving: break
    except urllib.error.HTTPError as e:
        if e.code in (301, 302, 307):
            loc = e.headers.get('Location', '')
            if '/gate' not in loc: serving = False  # redirected but not to gate → host matched, just not serving yet
    except Exception:
        pass
    time.sleep(6)
check('custom Host serves the app (middleware rewrite)', serving, 'host not mapped after 36s')

# cleanup the claim so future runs are clean
s, d, _ = req('DELETE', f'/api/custom-domains?id={DOMID}', token=ALICE)
check('domain claim removed', s == 200, str(s))

# ══ cleanup ════════════════════════════════════════════════════════════════
print('— cleanup')
def hard_del(pid, tok):
    try: req('DELETE', f'/api/projects/{pid}?hard=1', token=tok)
    except Exception: pass
for pid, tok in [(APROJ, ALICE), (BPROJ, BOB), (INSTALLED, BOB)]:
    hard_del(pid, tok)

print(f'\n════════ RESULT: {len(PASS)} passed, {len(FAIL)} failed ════════')
if FAIL:
    print('FAILED:')
    for f in FAIL: print(f'  ❌ {f}')
sys.exit(1 if FAIL else 0)
