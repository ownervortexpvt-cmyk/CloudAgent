#!/usr/bin/env python3
"""
e2e-v126-github-migration.py — proves the platform's GitHub publish feature
works with the owner's NEW account (mdhonabali02) after the old repo/account
(mdhonabali61-blip) got suspended.

Flow over REAL HTTP:
  1. owner login → GET /api/github → seeded account visible
  2. listRepos via operations route → new account's repos visible (token decrypt OK)
  3. create tiny project (1 file) → createRepo ca-live-test-<ts> → push
  4. verify the file EXISTS on GitHub (direct API)
  5. cleanup: delete GitHub repo + hard-delete project
"""
import json, sys, time, urllib.request, urllib.error

BASE = 'http://localhost:3000'
GATE = 'CA-X-MONA-9173'
OWNER = {'email': 'mdhonabali61@gmail.com', 'password': 'Owner123'}
NEW_PAT = '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'
NEW_USER = 'mdhonabali02'
STAMP = str(int(time.time()))
REPO = f'ca-live-test-{STAMP}'
PASS, FAIL = [], []

def check(name, cond, detail=''):
    (PASS if cond else FAIL).append(name)
    print(f"  {'PASS' if cond else 'FAIL'} {name}" + (f' — {detail}' if detail and not cond else ''))
    return cond

def req(method, path, body=None, token=None, timeout=120):
    data = json.dumps(body).encode() if body is not None else None
    h = {'Content-Type': 'application/json', 'x-ca-gate': GATE}
    if token: h['x-ca-lock'] = token
    r = urllib.request.Request(BASE + path, data=data, method=method, headers=h)
    try:
        with urllib.request.urlopen(r, timeout=timeout) as resp:
            try: return resp.status, json.loads(resp.read())
            except Exception: return resp.status, {'_raw': resp.read().decode('utf-8', 'replace')[:300]}
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read())
        except Exception: return e.code, {}
    except Exception as e:
        return 0, {'error': str(e)}

def gh(method, path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(f'https://api.github.com{path}', data=data, method=method,
        headers={'Authorization': f'token {NEW_PAT}', 'Accept': 'application/vnd.github+json', 'User-Agent': 'CloudAgent-E2E'})
    try:
        with urllib.request.urlopen(r, timeout=30) as resp:
            try: return resp.status, json.loads(resp.read())
            except Exception: return resp.status, {}
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read())
        except Exception: return e.code, {}

def main():
    print('── v126 GitHub migration — new account live proof ──')
    s, d = req('POST', '/api/auth/login', OWNER)
    tok = (d or {}).get('token')
    if not check('owner login', bool(tok), f's={s}'): sys.exit(1)

    s, d = req('GET', '/api/github', token=tok)
    accounts = (d or {}).get('accounts') or (d or {}).get('account') or []
    if isinstance(accounts, dict): accounts = [accounts]
    acc = next((a for a in accounts if a.get('username') == NEW_USER), None)
    if not check('seeded new account visible via API', acc is not None, f's={s} d={json.dumps(d)[:120]}'): sys.exit(1)
    accid = acc['id']

    s, d = req('POST', '/api/github/operations', {'action': 'listRepos', 'accountId': accid}, token=tok, timeout=60)
    repos = [((r or {}).get('full_name') or (r or {}).get('name') or '') for r in (d or {}).get('repos', [])]
    check('listRepos via platform (decrypt + token live)', s == 200 and any(NEW_USER in r or r for r in repos), f's={s} repos={repos[:4]}')

    s, d = req('POST', '/api/projects', {'name': f'GH Migration Test {STAMP}', 'language': 'html'}, token=tok)
    proj = (d or {}).get('project') or (d or {}).get('data') or {}
    pid = proj.get('id')
    if not check('test project created', bool(pid), f's={s}'): sys.exit(1)

    s, d = req('POST', f'/api/projects/{pid}/files' if False else f'/api/files/{pid}', {'path': 'index.html', 'content': f'<h1>CloudAgent alive on {NEW_USER}</h1><p>v126 migration test {STAMP}</p>'}, token=tok)
    if s in (404, 405):
        s, d = req('POST', '/api/files', {'projectId': pid, 'path': 'index.html', 'content': f'<h1>CloudAgent alive on {NEW_USER}</h1><p>v126 migration test {STAMP}</p>'}, token=tok)
    check('test file saved', s in (200, 201), f's={s} d={json.dumps(d)[:120]}')

    s, d = req('POST', '/api/github/operations', {'action': 'createRepo', 'accountId': accid, 'name': REPO, 'private': True}, token=tok, timeout=60)
    check('createRepo via platform', s in (200, 201), f's={s} d={json.dumps(d)[:150]}')

    s, d = req('POST', '/api/github/operations', {'action': 'push', 'accountId': accid, 'projectId': pid, 'repo': f'{NEW_USER}/{REPO}', 'message': f'v126 migration live test {STAMP}'}, token=tok, timeout=240)
    check('push via platform', s == 200 and (d or {}).get('ok', True), f's={s} d={json.dumps(d)[:200]}')

    # contents API can 404 for a few seconds right after a push (propagation lag)
    ok_file, body = False, ''
    for _ in range(4):
        gs, gd = gh('GET', f'/repos/{NEW_USER}/{REPO}/contents/index.html')
        if gs == 200 and 'content' in gd:
            import base64 as b64
            body = b64.b64decode(gd['content']).decode('utf-8', 'replace')
            ok_file = f'alive on {NEW_USER}' in body
            break
        time.sleep(3)
    check('app file at repo ROOT with correct content (v126 fix proof)', ok_file, f's={gs} body={body[:80]}')

    gs, gd = gh('GET', f'/repos/{NEW_USER}/{REPO}/contents/')
    names = [x.get('name') for x in gd] if isinstance(gd, list) else []
    leaks = [n for n in names if n in ('worklog.md', 'package.json', 'src', 'prisma', 'bun.lock', 'Caddyfile', '.prodmode', 'next.config.ts')]
    check('NO platform source leaked (root = app files only)', gs == 200 and not leaks, f'root={names[:10]} leaks={leaks}')
    gs2, gd2 = gh('GET', f'/repos/{NEW_USER}/{REPO}/commits')
    check('commit message on GitHub', gs2 == 200 and isinstance(gd2, list) and gd2 and 'v126 migration' in gd2[0]['commit']['message'], f's={gs2}')

    gs, _ = gh('DELETE', f'/repos/{NEW_USER}/{REPO}')
    check('cleanup: GitHub test repo deleted (or 403 = no delete_repo scope, harmless)', gs in (204, 200, 404, 403), f's={gs}')
    s, d = req('DELETE', f'/api/projects/{pid}?hard=1', token=tok)
    check('cleanup: test project hard-deleted', s in (200, 204, 404), f's={s}')

    print(f"\n=== v126 github-migration: {len(PASS)} PASS / {len(FAIL)} FAIL ===")
    if FAIL: print('FAILED:', FAIL); sys.exit(1)

if __name__ == '__main__':
    main()
