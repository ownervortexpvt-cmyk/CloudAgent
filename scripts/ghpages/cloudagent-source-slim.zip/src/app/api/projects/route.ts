import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ensureProjectDir } from '@/lib/storage'
import { getTemplate } from '@/lib/templates'
import { writeMany, writeFile } from '@/lib/storage'
import { detectFramework } from '@/lib/framework'
import { getLanguage, getLanguageScaffold } from '@/lib/languages'
import { generateProjectIcon } from '@/lib/icon-studio'
import { triggerProvisioning } from '@/lib/provision'
import { requireUser, UNAUTH_RESPONSE } from '@/lib/auth'
import { assertProjectCreate } from '@/lib/plan-guard'

export async function GET(req: NextRequest) {
  // BUSINESS v2: each account sees ITS OWN projects; admins see everything.
  // v62: trash support — the default list excludes soft-deleted projects;
  // ?trash=1 lists ONLY the trash bin.
  const user = await requireUser(req).catch(() => null)
  if (!user) return UNAUTH_RESPONSE()
  const trash = req.nextUrl.searchParams.get('trash') === '1'
  const projects = await db.project.findMany({
    where: {
      AND: [
        trash ? { NOT: { deletedAt: null } } : { deletedAt: null },
        user.role === 'admin' ? {} : { userId: user.id },
      ],
    },
    orderBy: { lastOpenedAt: 'desc' },
    take: 10000,
  })
  return NextResponse.json({ projects })
}

export async function POST(req: NextRequest) {
  // BUSINESS v2: the project is owned by the signed-in account; the plan
  // caps how many may exist.
  let user
  try {
    user = await requireUser(req)
    await assertProjectCreate(user)
  } catch (e: any) {
    if (e instanceof Response) return e as any
    throw e
  }
  const body = await req.json()
  const { name, description, templateId, framework, language, iconDataUrl, aiIcon } = body || {}

  if (!name) {
    return NextResponse.json({ error: 'name is required' }, { status: 400 })
  }

  const lang = language ? getLanguage(String(language)) : undefined
  if (language && !lang) {
    return NextResponse.json({ error: `unknown language: ${language}`, hint: `Supported: see /api/languages` }, { status: 400 })
  }
  // Language selection wins; explicit templateId still works (back-compat).
  const effectiveTemplateId = lang?.templateId || templateId

  const project = await db.project.create({
    data: {
      name,
      description: description || null,
      framework: framework || null,
      runtime: effectiveTemplateId ? (getTemplate(effectiveTemplateId)?.runtime || null) : null,
      userId: user.id,
    },
  })

  ensureProjectDir(project.id)
  const written: string[] = []
  if (effectiveTemplateId) {
    const tpl = getTemplate(effectiveTemplateId)
    if (tpl) {
      writeMany(project.id, tpl.files)
      for (const f of tpl.files) {
        await db.file.upsert({
          where: { projectId_path: { projectId: project.id, path: f.path } },
          create: { projectId: project.id, path: f.path, content: f.content, isDir: false },
          update: { content: f.content },
        })
      }
      written.push(...tpl.files.map(f => f.path))
    }
  }
  if (lang?.files?.length) {
    // Inline language starter (typescript / java / php) — written after any
    // template files so language scaffolding always lands on disk.
    for (const f of lang.files) {
      writeFile(project.id, f.path, f.content)
      await db.file.upsert({
        where: { projectId_path: { projectId: project.id, path: f.path } },
        create: { projectId: project.id, path: f.path, content: f.content, isDir: false },
        update: { content: f.content },
      })
    }
    written.push(...lang.files.map(f => f.path))
  }

  // Remember the builder choices (icon provenance + selected language) without
  // touching detection-based columns: framework/language stay auto-detected.
  try {
    const settings: Array<{ key: string; value: string }> = []
    if (lang) settings.push({ key: 'builderLanguage', value: lang.id })
    if (iconDataUrl) settings.push({ key: 'iconSource', value: 'upload' })
    if (aiIcon) settings.push({ key: 'iconSource', value: 'ai' })
    for (const s of settings) {
      await db.projectSetting.upsert({
        where: { projectId_key: { projectId: project.id, key: s.key } },
        create: { projectId: project.id, key: s.key, value: s.value },
        update: { value: s.value },
      })
    }
  } catch { /* settings are metadata — never fail the create */ }

  // Icon: uploaded image first, else REAL AI generation, both → assets/icon.png
  let icon: { files: string[]; source: string } | null = null
  let iconError: string | null = null
  try {
    if (iconDataUrl) {
      const { saveUploadedIcon } = await import('@/lib/icon-studio')
      icon = await saveUploadedIcon(project.id, String(iconDataUrl))
    } else if (aiIcon) {
      icon = await generateProjectIcon(project.id, name, description)
    }
  } catch (e: any) {
    iconError = e?.message || String(e)
  }

  const detection = detectFramework(project.id)
  await db.project.update({
    where: { id: project.id },
    data: { framework: detection.framework, runtime: detection.runtime, language: detection.language },
  })

  // v81 — Add Storage: the selected language decides which managed toolchains
  // the stack needs; missing ones install in the background right now (never
  // blocks the create; disk-guarded; result surfaces in the SDK Manager).
  let provision: ReturnType<typeof triggerProvisioning> | null = null
  try {
    provision = triggerProvisioning({
      projectId: project.id,
      projectName: name,
      language: lang?.id || detection.language,
      source: 'create',
    })
    if (provision.items.some(i => i.action === 'installing')) {
      await db.projectSetting.upsert({
        where: { projectId_key: { projectId: project.id, key: 'provisionNote' } },
        create: { projectId: project.id, key: 'provisionNote', value: `auto-setup started: ${provision.items.filter(i => i.action === 'installing').map(i => i.name).join(', ')}` },
        update: { value: `auto-setup started: ${provision.items.filter(i => i.action === 'installing').map(i => i.name).join(', ')}` },
      }).catch(() => {})
    }
  } catch { /* provisioning must never fail a create */ }

  return NextResponse.json({ project, written: written.length, icon, iconError, provision })
}
