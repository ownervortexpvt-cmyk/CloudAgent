import { NextRequest, NextResponse } from 'next/server'
import * as storage from '@/lib/storage'
import { db } from '@/lib/db'
import { requireProjectAccess, requireUser, UNAUTH_RESPONSE } from '@/lib/auth'

/**
 * GET /api/projects/storage?projectId=...
 * Returns storage usage for a project (total bytes, file count).
 * If no projectId, returns total across all projects.
 */
export async function GET(req: NextRequest) {
  const projectId = req.nextUrl.searchParams.get('projectId')
  // BUSINESS v2: verify the caller owns this project (admins exempt).
  if (projectId) {
    try { await requireProjectAccess(req, projectId) } catch (e: any) { if (e instanceof Response) return e as any; throw e }
  }
  // BUSINESS v2 (hardened): the all-projects totals are scoped to the
  // caller's own projects unless the caller is an admin.
  const user = await requireUser(req).catch(() => null)
  if (!user) return UNAUTH_RESPONSE() as any
  const projects = projectId
    ? [{ id: projectId }]
    : user.role === 'admin'
      ? await db.project.findMany({ select: { id: true } })
      : await db.project.findMany({ where: { userId: user.id }, select: { id: true } })

  let totalBytes = 0
  let totalFiles = 0
  const perProject: Array<{ id: string; bytes: number; files: number }> = []

  for (const p of projects) {
    try {
      const tree = storage.listTree(p.id)
      let bytes = 0
      let files = 0
      function walk(node: any) {
        if (node.type === 'file') {
          bytes += node.size || 0
          files++
        }
        if (node.children) for (const c of node.children) walk(c)
      }
      walk(tree)
      totalBytes += bytes
      totalFiles += files
      perProject.push({ id: p.id, bytes, files })
    } catch {}
  }

  function formatBytes(bytes: number): string {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  return NextResponse.json({
    totalBytes,
    totalFiles,
    totalFormatted: formatBytes(totalBytes),
    perProject: perProject.map(p => ({ ...p, formatted: formatBytes(p.bytes) })),
  })
}
