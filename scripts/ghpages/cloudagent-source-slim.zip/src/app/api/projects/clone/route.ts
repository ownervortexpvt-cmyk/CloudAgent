import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireProjectAccess, requireUser } from '@/lib/auth'
import { assertProjectCreate } from '@/lib/plan-guard'
import { ensureProjectDir, projectRoot, listTree } from '@/lib/storage'
import { detectFramework } from '@/lib/framework'
import fs from 'fs'
import path from 'path'

/**
 * POST /api/projects/clone { projectId } → full duplicate: every file on
 * disk is copied into a brand-new project, DB File rows are recreated, and
 * detection runs fresh. Runs/env/history stay with the original — a clone is
 * a snapshot of the code, not of the run logs.
 */
export async function POST(req: NextRequest) {
  let user
  try {
    user = await requireUser(req)
    await assertProjectCreate(user)
  } catch (e: any) {
    if (e instanceof Response) return e as any
    throw e
  }

  const body = await req.json().catch(() => null)
  const projectId = String((body as any)?.projectId || '')
  if (!projectId) return NextResponse.json({ error: 'projectId required' }, { status: 400 })

  try { await requireProjectAccess(req, projectId) } catch (e: any) { if (e instanceof Response) return e as any; throw e }
  const source = await db.project.findUnique({ where: { id: projectId }, include: { _count: { select: { files: true } } } })
  if (!source) return NextResponse.json({ error: 'project not found' }, { status: 404 })

  // Copy the whole workspace directory (binaries included, byte-exact).
  const srcRoot = projectRoot(source.id)
  const clone = await db.project.create({
    data: {
      name: `${source.name} (copy)`,
      description: source.description,
      framework: source.framework,
      language: source.language,
      runtime: source.runtime,
      entryPort: source.entryPort,
      userId: user.id,
    },
  })
  ensureProjectDir(clone.id)

  const dstRoot = projectRoot(clone.id)
  let fileCount = 0
  try {
    if (fs.existsSync(srcRoot)) {
      fs.cpSync(srcRoot, dstRoot, { recursive: true })
      const tree = listTree(clone.id, '.')
      const walk = (n: any): Array<{ path: string; isDir: boolean }> => {
        const out: Array<{ path: string; isDir: boolean }> = []
        if (!n) return out
        if (n.type === 'file') out.push({ path: n.path, isDir: false })
        else for (const c of n.children || []) out.push(...walk(c))
        return out
      }
      const entries = walk(tree)
      fileCount = entries.filter((e) => !e.isDir).length
      for (const e of entries) {
        await db.file.upsert({
          where: { projectId_path: { projectId: clone.id, path: e.path } },
          create: { projectId: clone.id, path: e.path, isDir: e.isDir, content: '' },
          update: {},
        }).catch(() => {})
      }
    }
  } catch (e: any) {
    // disk copy failed — don't leave a half-clone silently
    return NextResponse.json({ ok: false, error: e?.message || 'disk copy failed' }, { status: 500 })
  }

  // Refresh detection on the clone (cheap, honest).
  try {
    const detection = detectFramework(clone.id)
    await db.project.update({
      where: { id: clone.id },
      data: { framework: detection.framework, runtime: detection.runtime, language: detection.language },
    })
  } catch { /* keep copied fields on failure */ }

  return NextResponse.json({ ok: true, project: { id: clone.id, name: clone.name }, fileCount })
}
