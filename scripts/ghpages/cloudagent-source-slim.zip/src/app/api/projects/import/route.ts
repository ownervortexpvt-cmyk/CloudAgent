import { NextRequest, NextResponse } from 'next/server'
import AdmZip from 'adm-zip'
import { db } from '@/lib/db'
import { ensureProjectDir, projectRoot } from '@/lib/storage'
import { detectFramework } from '@/lib/framework'
import { sniffLanguage, triggerProvisioning } from '@/lib/provision'
import path from 'path'
import fs from 'fs'
import { requireUser } from '@/lib/auth'
import { assertProjectCreate } from '@/lib/plan-guard'

/**
 * POST /api/projects/import — create a project from a ZIP archive (v25).
 *
 * Body: { name, zipBase64 } (≤ 20 MB decoded)
 *  - writes every entry under projects/<newId> (path-traversal hardened)
 *  - if all entries share one top-level folder, that folder is stripped
 *  - creates the DB row + File rows, then runs framework detection
 */
const MAX_BYTES = 20 * 1024 * 1024
const SKIP_DIRS = new Set(['node_modules', '.git', '.next', 'coverage', 'build', 'dist', '__MACOSX'])

export async function POST(req: NextRequest) {
  // BUSINESS v2: imports are owned by the signed-in account and count
  // against its plan.
  let user
  try {
    user = await requireUser(req)
    await assertProjectCreate(user)
  } catch (e: any) {
    if (e instanceof Response) return e as any
    throw e
  }

  const body = await req.json().catch(() => null)
  const name = String((body as any)?.name || '').trim() || 'Imported project'
  const zipBase64 = String((body as any)?.zipBase64 || '')
  if (!zipBase64) return NextResponse.json({ error: 'zipBase64 required' }, { status: 400 })

  let zip: AdmZip
  try {
    const buf = Buffer.from(zipBase64, 'base64')
    if (buf.length === 0) return NextResponse.json({ error: 'zipBase64 is empty or not valid base64' }, { status: 400 })
    if (buf.length > MAX_BYTES) {
      return NextResponse.json({ error: `archive too large (${(buf.length / 1024 / 1024).toFixed(1)} MB) — the limit is 20 MB` }, { status: 413 })
    }
    zip = new AdmZip(buf)
  } catch {
    return NextResponse.json({ error: 'could not read the archive — is it a real .zip?' }, { status: 400 })
  }

  const entries = zip.getEntries().filter((e) => !e.isDirectory)
  if (entries.length === 0) return NextResponse.json({ error: 'the archive contains no files' }, { status: 400 })

  // If every entry lives under one shared top-level folder, strip it.
  const tops = new Set<string>()
  for (const e of entries) {
    const norm = e.entryName.replace(/\\/g, '/')
    tops.add(norm.includes('/') ? norm.slice(0, norm.indexOf('/')) : '')
  }
  const strip = tops.size === 1 && !tops.has('') ? [...tops][0] + '/' : ''

  const project = await db.project.create({
    data: { name, userId: user.id },
  })
  ensureProjectDir(project.id)

  // Path-traversal hardened write: normalize, refuse `..` and absolute paths.
  const root = projectRoot(project.id)
  const safeJoin = (rel: string): string | null => {
    const p = path.normalize(path.join(root, rel))
    if (!p.startsWith(root + path.sep) && p !== root) return null
    return p
  }

  const written: Array<{ path: string; content: string }> = []
  const touchedDirs = new Set<string>()
  for (const e of entries) {
    let rel = e.entryName.replace(/\\/g, '/')
    if (strip && rel.startsWith(strip)) rel = rel.slice(strip.length)
    if (!rel || rel.endsWith('/')) continue
    const parts = rel.split('/').filter((p) => p && p !== '.' && p !== '..')
    if (parts.length === 0) continue
    if (parts.some((p) => SKIP_DIRS.has(p))) continue
    rel = parts.join('/')
    const dest = safeJoin(rel)
    if (!dest) continue // traversal attempt — skipped, never written

    fs.mkdirSync(path.dirname(dest), { recursive: true })
    const data = e.getData()
    fs.writeFileSync(dest, data)

    // Index the file in the DB (text content when it decodes as UTF-8 —
    // binaries get an index row with empty content and are served from disk).
    const isText = !data.slice(0, 4096).includes(0)
    written.push({ path: rel, content: isText ? data.toString('utf8') : '' })
    for (let i = 1; i < parts.length; i++) {
      touchedDirs.add(parts.slice(0, i).join('/'))
    }
  }

  // DB index rows — dirs first, then files (upsert keeps re-imports idempotent).
  for (const d of touchedDirs) {
    await db.file.upsert({
      where: { projectId_path: { projectId: project.id, path: d } },
      create: { projectId: project.id, path: d, isDir: true, content: '' },
      update: {},
    }).catch(() => {})
  }
  for (const f of written) {
    await db.file.upsert({
      where: { projectId_path: { projectId: project.id, path: f.path } },
      create: { projectId: project.id, path: f.path, content: f.content, isDir: false },
      update: { content: f.content },
    }).catch(() => {})
  }

  // Framework + language detection, then background toolchain provisioning.
  const detection = detectFramework(project.id)
  await db.project.update({
    where: { id: project.id },
    data: { framework: detection.framework, runtime: detection.runtime, language: detection.language },
  }).catch(() => {})
  try {
    const lang = sniffLanguage(project.id)
    if (lang) {
      await db.project.update({ where: { id: project.id }, data: { language: lang } }).catch(() => {})
      triggerProvisioning({ projectId: project.id, projectName: name, language: lang, source: 'import' })
    }
  } catch { /* provisioning is best-effort */ }

  return NextResponse.json({ ok: true, project, fileCount: written.length })
}
