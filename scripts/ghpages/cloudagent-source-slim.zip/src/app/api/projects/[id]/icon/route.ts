import { NextRequest, NextResponse } from 'next/server'
import fs from 'fs'
import path from 'path'
import { projectRoot } from '@/lib/storage'

/**
 * Serve a project's icon (assets/icon.png) for dashboard cards / previews.
 * 404 when the project has no icon — the UI falls back to its placeholder.
 * Binary-safe: reads straight from disk (never through the utf8 readFile).
 */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const abs = path.join(projectRoot(id), 'assets', 'icon.png')
  if (!fs.existsSync(abs)) {
    return NextResponse.json({ error: 'no icon' }, { status: 404 })
  }
  const bin = fs.readFileSync(abs)
  return new Response(new Uint8Array(bin), {
    headers: { 'Content-Type': 'image/png', 'Cache-Control': 'no-store', 'Content-Length': String(bin.length) },
  })
}
