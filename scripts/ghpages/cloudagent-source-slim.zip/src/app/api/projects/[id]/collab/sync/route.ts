/**
 * v123 — /api/projects/[id]/collab/sync — the realtime pulse.
 * POST { tab?, since?, leaving? } → { online, events }
 *
 * Every open editor calls this every ~6s while the project is open:
 *   - registers presence (25s TTL on the server)
 *   - pulls fresh file events from other collaborators (id > since)
 *   - leaving=true → drops presence (tab closed)
 * Access: owner, admin, or ACTIVE collaborator — everyone else 403.
 */
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser } from '@/lib/auth'
import * as collab from '@/lib/collab'

export const runtime = 'nodejs'

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const user = await requireUser(req)
  const project = await db.project.findUnique({ where: { id }, select: { userId: true, deletedAt: true } })
  if (!project || project.deletedAt) {
    return NextResponse.json({ ok: false, error: 'project not found' }, { status: 404 })
  }
  let allowed = project.userId === user.id || user.role === 'admin'
  if (!allowed) {
    const coll = await db.projectCollaborator.findUnique({
      where: { projectId_userId: { projectId: id, userId: user.id } },
    })
    allowed = !!coll && coll.status === 'active'
  }
  if (!allowed) return NextResponse.json({ ok: false, error: 'no access to this project' }, { status: 403 })

  const body = await req.json().catch(() => ({}))
  const tab = String((body as any).tab || '').slice(0, 120)
  const since = Math.max(0, Number((body as any).since) || 0)

  if ((body as any).leaving) {
    collab.dropPeer(id, user.id)
    return NextResponse.json({ ok: true, online: [], events: [] })
  }

  const online = collab.beat(id, {
    userId: user.id,
    name: user.name || user.email.split('@')[0],
    email: user.email,
    tab,
  })
  const events = collab.eventsSince(id, since).filter((e) => e.byUserId !== user.id)
  return NextResponse.json({
    ok: true,
    online: online.map((p) => ({ userId: p.userId, name: p.name, color: p.color, tab: p.tab })),
    events,
    cursor: collab.lastEventId(id),
  })
}
