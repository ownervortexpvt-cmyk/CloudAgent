import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireProjectAccess, requireProjectOwner } from '@/lib/auth'
import * as storage from '@/lib/storage'
import fs from 'fs'
import path from 'path'

/**
 * /api/projects/[id] — project detail + metadata edit + trash/hard-delete.
 *  GET     → { project }                       (owner or admin)
 *  PATCH   { name?, description?, status? }    → whitelisted metadata edit
 *            (status: 'archived' | 'stopped' — v55 archive/unarchive)
 *  DELETE  → soft delete to Trash (v62); ?hard=1 removes files, versions and
 *            DB rows for real (the trash's "Delete forever").
 */
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  try { await requireProjectAccess(req, id) } catch (e: any) { if (e instanceof Response) return e as any; throw e }
  const project = await db.project.findUnique({
    where: { id },
    include: { _count: { select: { files: true, agents: true } } },
  })
  if (!project) return NextResponse.json({ error: 'not found' }, { status: 404 })
  return NextResponse.json({ ok: true, project })
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  try { await requireProjectAccess(req, id) } catch (e: any) { if (e instanceof Response) return e as any; throw e }
  const body = await req.json().catch(() => null)
  if (!body || typeof body !== 'object') return NextResponse.json({ error: 'body required' }, { status: 400 })

  // Whitelist — only these fields are user-editable metadata.
  const data: any = {}
  if (typeof body.name === 'string' && body.name.trim()) data.name = body.name.trim()
  if (body.description === null || typeof body.description === 'string') {
    data.description = body.description === null ? null : String(body.description).trim() || null
  }
  if (body.status === 'archived' || body.status === 'stopped') data.status = body.status

  if (Object.keys(data).length === 0) {
    return NextResponse.json({ error: 'nothing to update (allowed: name, description, status)' }, { status: 400 })
  }

  const project = await db.project.update({ where: { id }, data })
  return NextResponse.json({ ok: true, project: { id: project.id, name: project.name, description: project.description, status: project.status } })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  // v123: collaborators may edit — never delete (owner/admin only)
  try { await requireProjectOwner(req, id) } catch (e: any) { if (e instanceof Response) return e as any; throw e }
  const hard = req.nextUrl.searchParams.get('hard') === '1'
  const project = await db.project.findUnique({ where: { id } })
  if (!project) return NextResponse.json({ error: 'not found' }, { status: 404 })

  if (!hard) {
    // v62 soft delete — the project just leaves the normal lists. Files, runs,
    // env vars and snapshots stay exactly as they are, so Trash → Restore
    // brings it back byte-identical.
    await db.project.update({ where: { id }, data: { deletedAt: new Date() } })
    return NextResponse.json({ ok: true, trashed: true, id })
  }

  // HARD delete — destructive and honest: snapshot dirs on disk, the whole
  // project workspace, then the DB row (FK cascade takes files/runs/env/etc).
  try {
    const snapDir = path.join(process.cwd(), '.snapshots', id)
    if (fs.existsSync(snapDir)) fs.rmSync(snapDir, { recursive: true, force: true })
  } catch { /* snapshots may not exist */ }
  try {
    const root = storage.projectRoot(id)
    if (root && fs.existsSync(root)) fs.rmSync(root, { recursive: true, force: true })
  } catch { /* best-effort disk cleanup */ }
  await db.versionSnapshot.deleteMany({ where: { projectId: id } }).catch(() => {})
  await db.project.delete({ where: { id } }).catch(() => {})
  return NextResponse.json({ ok: true, deleted: true, id, hard: true })
}
