import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireProjectAccess } from '@/lib/auth'

/**
 * v62 — Trash restore. Clears a soft-deleted project's deletedAt so it
 * re-appears in the normal lists. Files, runs, env vars and snapshots were
 * never touched by the soft delete, so the project comes back exactly as it
 * was the moment it was trashed.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  // BUSINESS v2 (hardened): only the owner (or an admin) may restore.
  try { await requireProjectAccess(req, id) } catch (e: any) { if (e instanceof Response) return e as any; throw e }
  const project = await db.project.findUnique({ where: { id } })
  if (!project) return NextResponse.json({ error: 'not found' }, { status: 404 })
  if (!project.deletedAt) return NextResponse.json({ ok: true, restored: false, note: 'project was not in the trash' })
  await db.project.update({ where: { id }, data: { deletedAt: null } })
  return NextResponse.json({ ok: true, restored: true, project: { id: project.id, name: project.name } })
}
