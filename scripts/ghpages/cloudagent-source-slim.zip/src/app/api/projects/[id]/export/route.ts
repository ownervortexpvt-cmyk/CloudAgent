import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { runtimeManager } from '@/lib/runtime'
import { detectFramework } from '@/lib/framework'
import * as storage from '@/lib/storage'
import fs from 'fs'
import path from 'path'
import { requireProjectAccess } from '@/lib/auth'

/**
 * /api/projects/[id]/export — APK / EXE artifact export for one project.
 *  GET  ?kind=status                     → { targets: { apk, exe } } build states
 *  GET  ?kind=artifact&target=apk|exe    → streams the built artifact (if any)
 *  POST { target: 'apk' | 'exe' }        → starts a REAL build (flutter build apk
 *                                          for Flutter projects; npx builder for
 *                                          Electron projects) and returns honest
 *                                          logs — never a fake success.
 * Every build lands in the Build table + ArtifactMetadata, exactly like
 * /api/publish, so Publish history and Export stay one source of truth.
 */

const DOWNLOAD_DIR = '/home/z/my-project/download'

type TargetState = { state: 'idle' | 'building' | 'done' | 'failed'; message?: string; finishedAt?: string | null; artifact?: string | null }

async function statusFor(projectId: string): Promise<{ apk: TargetState; exe: TargetState }> {
  const builds = await db.build.findMany({
    where: { projectId, target: { in: ['apk', 'exe'] } },
    orderBy: { createdAt: 'desc' },
    take: 20,
  })
  const map = (target: 'apk' | 'exe'): TargetState => {
    const b = builds.find((x) => x.target === target)
    if (!b) return { state: 'idle' }
    if (b.status === 'running') return { state: 'building', message: 'build in progress…' }
    if (b.status === 'success') {
      const onDisk = b.artifactPath && fs.existsSync(b.artifactPath) ? b.artifactPath : null
      return { state: onDisk ? 'done' : 'failed', message: onDisk ? undefined : 'artifact missing on disk — rebuild', finishedAt: b.finishedAt?.toISOString?.() || null, artifact: onDisk }
    }
    return { state: 'failed', message: (b.logs || 'build failed').slice(-300), finishedAt: b.finishedAt?.toISOString?.() || null }
  }
  return { apk: map('apk'), exe: map('exe') }
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  try { await requireProjectAccess(req, id) } catch (e: any) { if (e instanceof Response) return e as any; throw e }
  const kind = req.nextUrl.searchParams.get('kind') || 'status'
  const project = await db.project.findUnique({ where: { id } })
  if (!project) return NextResponse.json({ error: 'project not found' }, { status: 404 })

  if (kind === 'status') {
    const targets = await statusFor(id)
    return NextResponse.json({ ok: true, projectId: id, projectName: project.name, targets })
  }

  if (kind === 'artifact') {
    const target = req.nextUrl.searchParams.get('target') as 'apk' | 'exe' | null
    if (target !== 'apk' && target !== 'exe') return NextResponse.json({ error: 'target must be apk or exe' }, { status: 400 })
    const b = await db.build.findFirst({
      where: { projectId: id, target, status: 'success', artifactPath: { not: null } },
      orderBy: { createdAt: 'desc' },
    })
    if (!b?.artifactPath || !fs.existsSync(b.artifactPath)) {
      return NextResponse.json({ error: `no ${target} artifact yet — build one first` }, { status: 404 })
    }
    const buf = fs.readFileSync(b.artifactPath)
    const fname = `${project.name.replace(/[^a-z0-9]+/gi, '-').toLowerCase() || 'project'}-${target}.${target}`
    return new NextResponse(new Uint8Array(buf), {
      headers: {
        'Content-Type': target === 'apk' ? 'application/vnd.android.package-archive' : 'application/octet-stream',
        'Content-Disposition': `attachment; filename="${fname}"`,
        'Content-Length': String(buf.length),
      },
    })
  }

  return NextResponse.json({ error: `unknown kind: ${kind}`, hint: 'status | artifact' }, { status: 400 })
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  try { await requireProjectAccess(req, id) } catch (e: any) { if (e instanceof Response) return e as any; throw e }
  const body = await req.json().catch(() => null)
  const target = String((body as any)?.target || '')
  if (target !== 'apk' && target !== 'exe') {
    return NextResponse.json({ error: 'target must be apk or exe' }, { status: 400 })
  }
  const project = await db.project.findUnique({ where: { id } })
  if (!project) return NextResponse.json({ error: 'project not found' }, { status: 404 })
  const detection = detectFramework(id)

  if (target === 'apk') {
    if (detection.framework !== 'flutter') {
      return NextResponse.json({ ok: false, error: 'APK builds require a Flutter project (pubspec.yaml).' })
    }
  } else {
    const pkgPath = storage.existsFile(id, 'package.json')
    const pkg = pkgPath ? (() => { try { return JSON.parse(storage.readFile(id, 'package.json')) } catch { return null } })() : null
    if (!pkg?.devDependencies?.electron && !pkg?.dependencies?.electron) {
      return NextResponse.json({
        ok: false,
        error: 'EXE builds require an Electron project (electron in package.json). ' +
          'Ask the agent: "convert this app to an Electron desktop app" first.',
      })
    }
  }

  const build = await db.build.create({ data: { projectId: id, target, status: 'running', startedAt: new Date() } })

  // Fire-and-forget: the dialog polls ?kind=status every 3s while building.
  void (async () => {
    try {
      let logs = ''
      let artifactPath: string | null = null
      if (target === 'apk') {
        // v80: cap the gradle JVM heap or the build OOM-kills this 4GB box.
        await runtimeManager.execInProject(id, "sed -i 's/^org.gradle.jvmargs=.*/org.gradle.jvmargs=-Xmx1024m -XX:MaxMetaspaceSize=384m/' android/gradle.properties 2>/dev/null; true", 15000)
        const r = await runtimeManager.execInProject(id, 'flutter build apk --release', 600000)
        logs = (r.stdout || '') + (r.stderr ? '\n' + r.stderr : '')
        const outDir = path.join(storage.projectRoot(id), 'build/app/outputs/flutter-apk')
        if (fs.existsSync(outDir)) {
          const found = fs.readdirSync(outDir).find((f) => f.endsWith('.apk'))
          if (found) {
            artifactPath = path.join(DOWNLOAD_DIR, `${id}.apk`)
            fs.mkdirSync(path.dirname(artifactPath), { recursive: true })
            fs.copyFileSync(path.join(outDir, found), artifactPath)
          }
        }
      } else {
        const r = await runtimeManager.execInProject(id, 'npx --yes electron-builder --win portable --x64', 600000)
        logs = (r.stdout || '') + (r.stderr ? '\n' + r.stderr : '')
        const distDir = path.join(storage.projectRoot(id), 'dist')
        if (fs.existsSync(distDir)) {
          const found = fs.readdirSync(distDir).find((f) => f.endsWith('.exe'))
          if (found) {
            artifactPath = path.join(DOWNLOAD_DIR, `${id}.exe`)
            fs.mkdirSync(path.dirname(artifactPath), { recursive: true })
            fs.copyFileSync(path.join(distDir, found), artifactPath)
          }
        }
      }
      const ok = !!artifactPath
      await db.build.update({
        where: { id: build.id },
        data: { status: ok ? 'success' : 'failed', artifactPath, logs: logs.slice(-20000) || (ok ? 'built' : 'no artifact produced'), finishedAt: new Date() },
      }).catch(() => {})
      if (ok) {
        await db.artifactMetadata.create({
          data: { buildId: build.id, sizeBytes: artifactPath ? fs.statSync(artifactPath).size : null, channel: 'stable' },
        }).catch(() => {})
      }
    } catch (e: any) {
      await db.build.update({
        where: { id: build.id },
        data: { status: 'failed', logs: String(e?.message || e).slice(-5000), finishedAt: new Date() },
      }).catch(() => {})
    }
  })()

  return NextResponse.json({ ok: true, buildId: build.id, message: `${target.toUpperCase()} build started — poll kind=status for progress` })
}
