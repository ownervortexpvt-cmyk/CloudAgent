/**
 * v123 — /api/projects/[id]/collab — membership management.
 *
 *   GET     → collaborators + pending list (owner/admin sees all; collaborators see peers)
 *   POST    → invite { email, role } — the user must ALREADY be registered
 *             (every CloudAgent account exists; email is the key). Inviting
 *             yourself or an existing collaborator → honest 409/400.
 *   DELETE  ?userId= → owner/admin removes a collaborator (soft → status removed)
 *
 * Only the project OWNER (or an admin) can invite/remove.
 */
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser } from '@/lib/auth'
import * as collab from '@/lib/collab'

export const runtime = 'nodejs'

async function loadProject(req: NextRequest, id: string): Promise<{ error?: NextResponse; user?: any; isOwner?: boolean; isAdmin?: boolean }> {
  const user = await requireUser(req)
  const project = await db.project.findUnique({ where: { id } })
  if (!project || project.deletedAt) return { error: NextResponse.json({ ok: false, error: 'project not found' }, { status: 404 }) }
  const isOwner = project.userId === user.id
  const isAdmin = user.role === 'admin'
  return { user, isOwner, isAdmin }
}

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const L = await loadProject(req, id)
  if (L.error) return L.error
  const rows = await db.projectCollaborator.findMany({
    where: { projectId: id, status: 'active' },
    orderBy: { createdAt: 'asc' },
  })
  const live = collab.beat(id, { userId: L.user!.id, name: L.user!.name || L.user!.email, email: L.user!.email, tab: '' })
    .filter((p) => p.tab !== '' || p.userId === L.user!.id)
  return NextResponse.json({
    ok: true,
    collaborators: rows.map((r) => ({ userId: r.userId, name: r.name, email: r.email, role: r.role, createdAt: r.createdAt })),
    online: live.map((p) => ({ userId: p.userId, name: p.name, color: p.color, tab: p.tab })),
    isOwner: L.isOwner || L.isAdmin,
  })
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const L = await loadProject(req, id)
  if (L.error) return L.error
  if (!L.isOwner && !L.isAdmin) {
    return NextResponse.json({ ok: false, error: 'only the project owner can invite collaborators' }, { status: 403 })
  }
  const body = await req.json().catch(() => ({}))
  const email = String((body as any).email || '').toLowerCase().trim()
  const role = (body as any).role === 'viewer' ? 'viewer' : 'editor'
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    return NextResponse.json({ ok: false, error: 'ekta valid email din' }, { status: 400 })
  }
  if (email === L.user!.email) {
    return NextResponse.json({ ok: false, error: 'you already own this project' }, { status: 400 })
  }
  const invitee = await db.authUser.findUnique({ where: { email } })
  if (!invitee) {
    return NextResponse.json({ ok: false, error: 'ei email e kono CloudAgent account nei — Age register korte hobe' }, { status: 404 })
  }
  const dupe = await db.projectCollaborator.findUnique({
    where: { projectId_userId: { projectId: id, userId: invitee.id } },
  })
  if (dupe && dupe.status === 'active') {
    return NextResponse.json({ ok: false, error: 'ini already collaborator' }, { status: 409 })
  }
  const row = dupe
    ? await db.projectCollaborator.update({ where: { id: dupe.id }, data: { status: 'active', role } })
    : await db.projectCollaborator.create({
        data: { projectId: id, userId: invitee.id, email, name: invitee.name || email.split('@')[0], role, invitedBy: L.user!.id },
      })
  return NextResponse.json({ ok: true, collaborator: { userId: row.userId, name: row.name, email: row.email, role: row.role } })
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const L = await loadProject(req, id)
  if (L.error) return L.error
  if (!L.isOwner && !L.isAdmin) {
    return NextResponse.json({ ok: false, error: 'only the project owner can remove collaborators' }, { status: 403 })
  }
  const userId = req.nextUrl.searchParams.get('userId') || ''
  const row = await db.projectCollaborator.findUnique({ where: { projectId_userId: { projectId: id, userId } } })
  if (row) {
    await db.projectCollaborator.update({ where: { id: row.id }, data: { status: 'removed' } })
    collab.dropPeer(id, userId)
  }
  return NextResponse.json({ ok: true })
}
