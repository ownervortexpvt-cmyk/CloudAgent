/**
 * v117.3 — DB AUTO-HEAL at boot (the platform's #1 recurring failure).
 *
 * The sandbox recycles wipe db/custom.db rows every few hours. Three times
 * now this silently killed the product: the built-in Z.ai provider rows
 * vanished (builder looked "broken"), and the QA admin disappeared (every
 * regression suite failed with 401). The owner then had to re-register
 * himself and file "kaj kore na" complaints.
 *
 * ensureDbHeal() runs once per server process at boot and is IDEMPOTENT:
 *   1. re-seeds the 3 built-in Z.ai provider rows when they are missing
 *   2. re-creates the QA admin (qa-admin115@qa.local) used by the e2e suites
 *   3. v122: re-creates the OWNER (mdhonabali61@gmail.com) when a recycle
 *      wiped the row — 4th recycle locked the owner out of his own platform
 *      ("admin login hote parsina"). Fresh create uses the password he set in
 *      chat (Owner123). If the row EXISTS its password is NEVER touched; only
 *      a demoted role/plan is restored (admin / ultra_pro_max) so he can
 *      never lose the control room.
 *
 * Failure of the heal itself is contained: every step is wrapped, a failed
 * heal only logs — boot continues.
 */
import crypto from 'crypto'

const QA_EMAIL = 'qa-admin115@qa.local'
const QA_PASSWORD = 'qatester115'

/** The platform owner — restored at boot if a recycle wipes him. */
const OWNER_EMAIL = 'mdhonabali61@gmail.com'
const OWNER_PASSWORD = 'Owner123'

const BUILT_INS = [
  { name: 'GLM 5.3 Flash', kind: 'zai', model: 'glm-5.3-flash', isDefault: true },
  { name: 'GLM 5.3', kind: 'zai', model: 'glm-5.3', isDefault: false },
  { name: 'GLM 4.6', kind: 'zai', model: 'glm-4.6', isDefault: false },
]

function hashPassword(pw: string): string {
  const salt = crypto.randomBytes(16).toString('hex')
  const hash = crypto.scryptSync(pw, salt, 64).toString('hex')
  return `${salt}:${hash}`
}

let healed = false

export async function ensureDbHeal(): Promise<void> {
  if (healed) return
  healed = true
  try {
    const { db } = await import('@/lib/db')

    // 1. built-in Z.ai provider rows (global rows — userId is null)
    try {
      const existing = await db.aIProvider.findMany({
        where: { kind: 'zai' },
        select: { name: true },
      })
      const have = new Set(existing.map((r: any) => r.name))
      const missing = BUILT_INS.filter((b) => !have.has(b.name))
      if (missing.length > 0) {
        for (const b of missing) {
          await db.aIProvider.create({ data: { ...b, category: 'free', role: 'work' } as any })
        }
        console.log(`[boot-heal] re-seeded ${missing.length} built-in Z.ai provider row(s) after recycle`)
      }
    } catch (e: any) {
      console.error('[boot-heal] provider seed failed:', e?.message)
    }

    // 2. QA admin for the regression suites
    try {
      const qa = await db.authUser.findUnique({ where: { email: QA_EMAIL } })
      if (!qa) {
        await db.authUser.create({
          data: {
            email: QA_EMAIL,
            name: 'QA Admin 115',
            role: 'admin',
            plan: 'ultra_pro_max',
            status: 'active',
            passwordHash: hashPassword(QA_PASSWORD),
          } as any,
        })
        console.log('[boot-heal] re-created QA admin after recycle')
      }
    } catch (e: any) {
      console.error('[boot-heal] qa-admin seed failed:', e?.message)
    }

    // 3. v122 — OWNER self-restore (recycles kept locking him out)
    try {
      const owner = await db.authUser.findUnique({ where: { email: OWNER_EMAIL } })
      if (!owner) {
        await db.authUser.create({
          data: {
            email: OWNER_EMAIL,
            name: 'Md Honabali',
            role: 'admin',
            plan: 'ultra_pro_max',
            planKind: 'admin',
            status: 'active',
            passwordHash: hashPassword(OWNER_PASSWORD),
          } as any,
        })
        console.log('[boot-heal] re-created OWNER account after recycle (default password restored)')
      } else if (owner.role !== 'admin' || owner.plan !== 'ultra_pro_max') {
        await db.authUser.update({
          where: { email: OWNER_EMAIL },
          data: { role: 'admin', plan: 'ultra_pro_max', planKind: 'admin', status: 'active' },
        })
        console.log('[boot-heal] restored OWNER role/plan after recycle (password untouched)')
      }
    } catch (e: any) {
      console.error('[boot-heal] owner seed failed:', e?.message)
    }

    // 4. v123 — PRIVATE GATE key (site stays locked to owner+operator after recycles)
    try {
      const { getGate } = await import('@/lib/gate')
      const gate = await getGate() // seeds UserSetting row on first boot, caches after
      console.log('[boot-heal] private gate active (key seeded)')
      void gate
    } catch (e: any) {
      console.error('[boot-heal] gate seed failed:', e?.message)
    }
  } catch (e: any) {
    console.error('[boot-heal] db heal skipped:', e?.message)
  }
}
